# Body Brain Bot - Sam vs Bot "The weather" skit (Blender 5.x)
# 2D cut-out characters with moving arms/legs/heads in a 3D room, camera cuts, depth of field,
# captions + sound added in Blender's video editor. Output: weather-1080x1920.mp4
import bpy, os, json, math

def find_here():
    cands = []
    try:
        cands.append(os.path.dirname(os.path.abspath(__file__)))
    except NameError:
        pass
    cands += [os.environ.get("BBB_DIR", ""), os.getcwd()]
    for c in cands:
        if c and os.path.exists(os.path.join(c, "timeline.json")):
            return c
    raise RuntimeError("Can't find the kit folder (timeline.json).")

HERE = find_here()
PARTS = os.path.join(HERE, "parts")
META = json.load(open(os.path.join(HERE, "parts.json")))
TL = json.load(open(os.path.join(HERE, "timeline.json")))
CAPS = json.load(open(os.path.join(HERE, "captions.json")))
FPS = TL["fps"]
NF = TL["frames"]

PCT = int(os.environ.get("BBB_PCT", "100"))
SAMPLES = int(os.environ.get("BBB_SAMPLES", "20"))
STILLS = os.environ.get("BBB_STILLS", "")
CPU_ONLY = os.environ.get("BBB_CPU", "") == "1"
OUTNAME = os.environ.get("BBB_OUT", "weather-1080x1920.mp4")
END = int(os.environ.get("BBB_END", NF))
PX = 0.0016   # metres per sprite pixel
GREY = os.environ.get("BBB_GREY", "") == "1"     # neutral blocking pass for Seedance @video (grey shapes, only arch lights coloured)
START = int(os.environ.get("BBB_START", "1"))

# ---------------------------------------------------------------- scene
edit = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
for s in list(bpy.data.scenes):
    if s != edit:
        bpy.data.scenes.remove(s)
for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.curves, bpy.data.lights, bpy.data.cameras, bpy.data.images):
    for b in list(coll):
        if b.users == 0:
            coll.remove(b)
if edit.sequence_editor:
    edit.sequence_editor_clear()
edit.name = "EDIT"
scene = bpy.data.scenes.new("SKIT")
scene.frame_start, scene.frame_end = START, END
scene.render.fps = FPS
scene.render.resolution_x, scene.render.resolution_y = 1080, 1920
scene.render.resolution_percentage = PCT

def link(o):
    scene.collection.objects.link(o)
    return o

def hexrgb(h):
    h = h.lstrip("#")
    c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return tuple(((x + 0.055) / 1.055) ** 2.4 if x > 0.04045 else x / 12.92 for x in c)

def mat(name, col, rough=0.6, emit=0.0, metal=0.0, keep=False):
    if GREY and not keep:
        col, emit, metal = "#34373D", 0.0, 0.0
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes.get("Principled BSDF")
    rgb = hexrgb(col) if isinstance(col, str) else col
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if emit:
        b.inputs["Emission Color"].default_value = (*rgb, 1)
        b.inputs["Emission Strength"].default_value = emit
    return m

def img_mat(path, strength=1.0, alpha=True):
    m = bpy.data.materials.new(os.path.basename(path))
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(path, check_existing=True)
    tex.extension = "CLIP"
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Strength"].default_value = strength
    if GREY:
        b = os.path.basename(path)
        g = 0.55 if b.startswith("bot") else (0.30 if b.startswith("off") else (0.85 if b.startswith(("sam", "shoes")) else 0.08))
        if b.startswith("shadow"):
            g = 0.0
        em.inputs["Color"].default_value = (g, g, g, 1)
    else:
        nt.links.new(tex.outputs["Color"], em.inputs["Color"])
    if alpha:
        tr = nt.nodes.new("ShaderNodeBsdfTransparent")
        mix = nt.nodes.new("ShaderNodeMixShader")
        nt.links.new(tex.outputs["Alpha"], mix.inputs[0])
        nt.links.new(tr.outputs[0], mix.inputs[1])
        nt.links.new(em.outputs[0], mix.inputs[2])
        nt.links.new(mix.outputs[0], out.inputs[0])
    else:
        nt.links.new(em.outputs[0], out.inputs[0])
    return m

def box(name, x0, x1, y0, y1, z0, z1, m, parent=None):
    me = bpy.data.meshes.new(name)
    v = [(x, y, z) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]
    f = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    me.from_pydata(v, [], f)
    me.materials.append(m)
    o = link(bpy.data.objects.new(name, me))
    if parent:
        o.parent = parent
    return o

def cyl(name, x, y, z0, z1, r, m, seg=24, r2=None):
    r2 = r if r2 is None else r2
    me = bpy.data.meshes.new(name)
    v, f = [], []
    for i in range(seg):
        a = 2 * math.pi * i / seg
        v += [(x + r * math.cos(a), y + r * math.sin(a), z0), (x + r2 * math.cos(a), y + r2 * math.sin(a), z1)]
    for i in range(seg):
        j = (i + 1) % seg
        f.append((2 * i, 2 * j, 2 * j + 1, 2 * i + 1))
    f.append(tuple(2 * i for i in range(seg))[::-1])
    f.append(tuple(2 * i + 1 for i in range(seg)))
    me.from_pydata(v, [], f)
    me.materials.append(m)
    for p in me.polygons:
        p.use_smooth = True
    return link(bpy.data.objects.new(name, me))

def sphere(name, loc, r, m):
    me = bpy.data.meshes.new(name)
    v, f, nu, nv = [], [], 16, 10
    for j in range(nv + 1):
        th = math.pi * j / nv
        for i in range(nu):
            ph = 2 * math.pi * i / nu
            v.append((r * math.sin(th) * math.cos(ph), r * math.sin(th) * math.sin(ph), r * math.cos(th)))
    for j in range(nv):
        for i in range(nu):
            a, b = j * nu + i, j * nu + (i + 1) % nu
            f.append((a, b, b + nu, a + nu))
    me.from_pydata(v, [], f)
    me.materials.append(m)
    for p in me.polygons:
        p.use_smooth = True
    o = link(bpy.data.objects.new(name, me))
    o.location = loc
    return o

def quad(name, w, h, m, cx=0.0, cz=0.0):
    """vertical quad in XZ plane facing -Y, centred at (cx, cz)"""
    me = bpy.data.meshes.new(name)
    me.from_pydata([(cx - w / 2, 0, cz - h / 2), (cx + w / 2, 0, cz - h / 2), (cx + w / 2, 0, cz + h / 2), (cx - w / 2, 0, cz + h / 2)], [], [(0, 1, 2, 3)])
    me.uv_layers.new()
    for i, c in enumerate([(0, 0), (1, 0), (1, 1), (0, 1)]):
        me.uv_layers[0].data[i].uv = c
    me.materials.append(m)
    o = link(bpy.data.objects.new(name, me))
    try:
        o.visible_shadow = False
    except Exception:
        pass
    return o

def empty(name, parent=None, loc=(0, 0, 0)):
    e = link(bpy.data.objects.new(name, None))
    e.empty_display_size = 0.05
    if parent:
        e.parent = parent
    e.location = loc
    return e

def sprite(part, parent, depth=0.0, name=None):
    """plane for a part, its pivot at the parent's origin"""
    m = META[part]
    w, h = m["w"] * PX, m["h"] * PX
    cx = (m["w"] / 2 - m["px"]) * PX
    cz = (m["py"] - m["h"] / 2) * PX
    o = quad(name or part, w, h, img_mat(os.path.join(PARTS, part + ".png")), cx, cz)
    o.parent = parent
    o.location = (0, depth, 0)
    return o
# ---------------------------------------------------------------- sunny living room
def emat(name, col, strength):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt2 = m.node_tree
    nt2.nodes.clear()
    o2 = nt2.nodes.new("ShaderNodeOutputMaterial")
    e2 = nt2.nodes.new("ShaderNodeEmission")
    e2.inputs["Color"].default_value = (*hexrgb(col), 1)
    e2.inputs["Strength"].default_value = strength
    nt2.links.new(e2.outputs[0], o2.inputs[0])
    return m
def checker(name, c1, c2, scale, rough=0.7):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    ck = nt.nodes.new("ShaderNodeTexChecker")
    ck.inputs["Scale"].default_value = scale
    ck.inputs["Color1"].default_value = (*hexrgb(c1), 1)
    ck.inputs["Color2"].default_value = (*hexrgb(c2), 1)
    tc = nt.nodes.new("ShaderNodeTexCoord")
    nt.links.new(tc.outputs["Object"], ck.inputs["Vector"])
    nt.links.new(ck.outputs["Color"], nt.nodes["Principled BSDF"].inputs["Base Color"])
    nt.nodes["Principled BSDF"].inputs["Roughness"].default_value = rough
    return m
FLOOR = checker("floor", "#D9A86C", "#CF9C60", 5.0, 0.5)
WALLM = mat("wall", "#F7DC7A", 0.85)
WAIN = mat("wainscot", "#FFFFFF", 0.6)
TRIM = mat("trim", "#FFFFFF", 0.5)
RUG = mat("rug", "#5BA6C9", 0.9)
RUG2 = mat("rug2", "#E9F3F7", 0.9)
PLAID = checker("plaid", "#E2434E", "#FFF4EC", 9.0, 0.85)
SOFA = mat("sofa", "#7C5CBF", 0.8)
SOFA2 = mat("sofa2", "#6A4CAA", 0.8)
WOOD = mat("wood", "#A8744C", 0.5)
POT = mat("pot", "#D46A3C", 0.6)
LEAF = mat("leaf", "#3E9A55", 0.6)
FRAMEM = mat("frame_dark", "#2A2733", 0.4)

WY = 2.2
box("floor", -5, 5, -7, 6, -0.05, 0, FLOOR)
box("wall_back", -5, 5, WY, WY + 0.1, 0, 4.2, WALLM)
box("wainscot", -5, 5, WY - 0.03, WY, 0, 0.9, WAIN)
box("wain_trim", -5, 5, WY - 0.05, WY, 0.9, 0.95, TRIM)
# big sunny window (top left, above Sam's head)
WIN_X, WIN_Z = -0.75, 2.30
sky = quad("sky", 1.30, 1.00, img_mat(os.path.join(PARTS, "sky_day.png"), 1.6, alpha=False), WIN_X, WIN_Z)
sky.location = (0, WY - 0.02, 0)
for (x0, x1, z0, z1) in ((WIN_X - 0.70, WIN_X - 0.62, WIN_Z - 0.55, WIN_Z + 0.55), (WIN_X + 0.62, WIN_X + 0.70, WIN_Z - 0.55, WIN_Z + 0.55),
                         (WIN_X - 0.70, WIN_X + 0.70, WIN_Z + 0.50, WIN_Z + 0.58), (WIN_X - 0.70, WIN_X + 0.70, WIN_Z - 0.58, WIN_Z - 0.50),
                         (WIN_X - 0.03, WIN_X + 0.03, WIN_Z - 0.5, WIN_Z + 0.5)):
    box("frame", x0, x1, WY - 0.06, WY - 0.02, z0, z1, TRIM)
box("sill", WIN_X - 0.8, WIN_X + 0.8, WY - 0.16, WY - 0.05, WIN_Z - 0.62, WIN_Z - 0.56, TRIM)
# sofa (right, partly off frame)
box("sofa_base", 1.05, 2.6, WY - 0.75, WY - 0.05, 0.1, 0.5, SOFA)
box("sofa_back", 1.05, 2.6, WY - 0.30, WY - 0.05, 0.5, 1.05, SOFA2)
box("sofa_arm", 1.0, 1.2, WY - 0.80, WY - 0.05, 0.1, 0.72, SOFA2)
for x in (1.4, 2.0):
    box("cushion", x - 0.24, x + 0.24, WY - 0.42, WY - 0.30, 0.5, 0.9, mat("cush", "#F2B84B", 0.8))
# plant (left)
cyl("pot", -1.55, 1.6, 0, 0.45, 0.2, POT, 24, 0.24)
for i, (dx, dz, r) in enumerate(((0, 0.75, 0.30), (-0.18, 0.62, 0.22), (0.18, 0.66, 0.22), (0, 0.98, 0.2))):
    sphere("leaf%d" % i, (-1.55 + dx, 1.6, dz), r, LEAF)
# rug under the characters
cyl("rug", 0, 0.45, 0, 0.006, 1.35, RUG, 48)
cyl("rug_in", 0, 0.45, 0.006, 0.010, 1.05, RUG2, 48)
cyl("rug_in2", 0, 0.45, 0.010, 0.013, 0.95, RUG, 48)
# wall clock above Bot (2:59)
CLK = empty("clock_e", None, (0.72, WY - 0.04, 2.30))
CLK.scale = (0.9, 0.9, 0.9)
sprite("clock_face", CLK, 0, "clock_face_s")
CLK_H = empty("clock_h", CLK, (0, -0.004, 0))
CLK_M = empty("clock_m", CLK, (0, -0.008, 0))
sprite("clock_hour", CLK_H, 0, "clock_hour_s")
sprite("clock_min", CLK_M, 0, "clock_min_s")
# picnic blanket (thin plaid box) + basket; animated in
BLK = empty("blanket_e", None, (-0.42, 0.40, 0.0))
bl = box("blanket", -0.55, 0.55, -0.42, 0.42, 0.0, 0.012, PLAID)
bl.parent = BLK
BSK = empty("basket_e", None, (-1.02, 0.30, 0.012))
BSK.scale = (0.75, 0.75, 0.75)
sprite("basket", BSK, 0, "basket_s")

# ---------------------------------------------------------------- lights + world
world = scene.world or bpy.data.worlds.new("World")
scene.world = world
world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (*hexrgb("#BFE3FF"), 1)
world.node_tree.nodes["Background"].inputs[1].default_value = 0.8

def light(name, kind, loc, energy, color="#FFFFFF", size=1.0, rot=(0, 0, 0)):
    l = bpy.data.lights.new(name, kind)
    l.energy = energy
    l.color = hexrgb(color)
    if kind == "AREA":
        l.size = size
    if kind in ("POINT", "SPOT"):
        l.shadow_soft_size = size
    if kind == "SUN":
        l.angle = math.radians(8)
    o = link(bpy.data.objects.new(name, l))
    o.location = loc
    o.rotation_euler = rot
    return o

light("sun", "SUN", (0, 0, 5), 2.2, "#FFE7B5", 1.0, (math.radians(50), 0, math.radians(-160)))
light("key", "AREA", (-0.8, -3.0, 3.2), 320, "#FFF1DC", 3.5, (math.radians(45), 0, math.radians(-12)))
light("fill", "AREA", (2.5, -2.0, 2.4), 140, "#DDEBFF", 2.5, (math.radians(55), 0, math.radians(45)))
light("ceiling", "AREA", (0, 0.6, 3.9), 160, "#FFF4E0", 4.0, (0, 0, 0))

# ---------------------------------------------------------------- characters
def build_human(pre, leg, fores, mouths, scale=1.0, torso_part=None, name=None, head_part="sam_head"):
    root = empty((name or pre).upper())
    hip = empty(pre + "_hip", root, (0, 0, 330 * PX))
    legB = empty(pre + "_legB", hip, (-0.06, 0.03, 0))
    legF = empty(pre + "_legF", hip, (0.06, -0.03, 0))
    sprite(leg, legB, 0, pre + "_leg_b")
    sprite(leg, legF, 0, pre + "_leg_f")
    torso = empty(pre + "_torso_j", hip)
    sprite(torso_part or (pre + "_torso"), torso, 0)
    shB = empty(pre + "_shB", torso, (-90 * PX, 0.03, 245 * PX))
    shF = empty(pre + "_shF", torso, (90 * PX, -0.03, 245 * PX))
    neck = empty(pre + "_neck", torso, (0, -0.01, 290 * PX))
    P = {}
    for side, sh in (("B", shB), ("F", shF)):
        sprite("sam_upper", sh, 0, pre + "_upper_" + side)
        el = empty(pre + "_el" + side, sh, (0, 0, -100 * PX))
        sprite(fores[0], el, -0.002, pre + "_fore_" + side)
        P["sh" + side], P["el" + side] = sh, el
    head = empty(pre + "_head_j", neck)
    sprite(head_part, head, 0, pre + "_head")
    face = {}
    for grp, names, d in (("eyes", ["open", "blink", "wide", "half", "front"], -0.004),
                          ("brows", ["neutral", "up", "angry", "sad"], -0.006),
                          ("mouth", mouths, -0.005)):
        face[grp] = {n: sprite("sam_%s_%s" % (grp, n), head, d, "%s_%s_%s" % (pre, grp, n)) for n in names}
    root.scale = (scale, scale, scale)
    P.update(root=root, hip=hip, torso=torso, neck=neck, head=head, legB=legB, legF=legF, face=face, scale=scale)
    return P

def build_bot():
    root = empty("BOT")
    body = empty("bot_body_j", root)
    sprite("bot_body", body, 0)
    shB = empty("bot_shB", body, (-118 * PX, 0.03, 330 * PX))
    shF = empty("bot_shF", body, (118 * PX, -0.03, 330 * PX))
    sprite("bot_arm", shB, 0, "bot_arm_B")
    sprite("bot_arm", shF, 0, "bot_arm_F")
    neck = empty("bot_neck", body, (0, -0.01, 372 * PX))
    head = empty("bot_head_j", neck)
    sprite("bot_head", head, 0)
    ant = empty("bot_ant", head, (0, 0.004, 328 * PX))
    sprite("bot_antenna", ant, 0)
    face = {}
    for grp, names, d in (("eyes", ["open", "blink", "happy", "flat", "side", "think", "wink"], -0.004), ("mouth", ["line", "small", "open", "smirk", "wave"], -0.006)):
        face[grp] = {n: sprite("bot_%s_%s" % (grp, n), head, d) for n in names}
    return dict(root=root, body=body, shB=shB, shF=shF, neck=neck, head=head, ant=ant, face=face)

MOUTHS = ["smile", "flat", "frown", "small", "open", "wide", "o"]
SAM = build_human("sam", "sam_leg", ["sam_fore"], MOUTHS)
BOT = build_bot()
# Sam's extras on the head: glasses (straight / crooked), wet drops, towel
GL = {n: sprite("sam_" + n, SAM["head"], -0.008, "x_" + n) for n in ("glasses", "glasses_crooked")}
WET = sprite("sam_wet", SAM["head"], -0.009, "x_wet")
TWH = sprite("towel_head", SAM["head"], -0.010, "x_towel_head")
# umbrellas: Bot's (in his front hand) and Sam's (after the grab)
def umbrella(pre, arm_e, hand_px):
    e = empty(pre + "_umb_e", arm_e, (0, -0.012, -hand_px * PX))
    return e, {"closed": sprite("umb_closed", e, 0, pre + "_umb_closed"), "open": sprite("umb_open", e, 0, pre + "_umb_open")}
UB_E, UB = umbrella("bot", BOT["shF"], 190)
UBC_E, UBC = umbrella("botc", BOT["shB"], 190)
US_E, US = umbrella("sam", SAM["elF"], 150)
# towel in Bot's back hand, flies to Sam's head
TWF = empty("towel_fly", None, (0, 0, 0))
TWF.scale = (0.55, 0.55, 0.55)
sprite("towel_folded", TWF, 0, "towel_folded_s")
# rain cloud: cloud + 3 rain frames + splash
CL = empty("cloud_e", None, (-0.45, 0.36, 2.15))
CLS = sprite("cloud", CL, 0, "cloud_s")
RAIN_E = empty("rain_e", CL, (0, 0.0, -0.02))
RAIN = {k: sprite("rain%d" % k, RAIN_E, 0, "rain_s%d" % k) for k in range(3)}
SPL = empty("splash_e", None, (0, 0, 0))
SPL.scale = (0.7, 0.7, 0.7)
SPLS = sprite("splash", SPL, 0, "splash_s")
# ---------------------------------------------------------------- camera
camd = bpy.data.cameras.new("cam")
camd.sensor_fit = "VERTICAL"
camd.sensor_height = 36
camd.dof.use_dof = True
cam = link(bpy.data.objects.new("cam", camd))
scene.camera = cam
# ---------------------------------------------------------------- camera
camd = bpy.data.cameras.new("cam")
camd.sensor_fit = "VERTICAL"
camd.sensor_height = 36
camd.dof.use_dof = True
cam = link(bpy.data.objects.new("cam", camd))
scene.camera = cam

# ---------------------------------------------------------------- animation helpers
def T(f):
    return (f - 1) / FPS

def ease(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)

def back(x, s=1.6):
    x = max(0.0, min(1.0, x))
    x -= 1
    return x * x * ((s + 1) * x + s) + 1

def track(keys, t, blend=0.22, fn=None):
    """keys: list of (time, value-dict). returns blended dict with overshoot"""
    fn = fn or back
    prev = keys[0][1]
    cur = keys[0][1]
    t0 = keys[0][0]
    for tk, v in keys:
        if t >= tk:
            prev, cur, t0 = cur, v, tk
    k = fn((t - t0) / blend)
    return {n: prev.get(n, 0) + (cur.get(n, 0) - prev.get(n, 0)) * k for n in cur}

def step(keys, t):
    v = keys[0][1]
    for tk, val in keys:
        if t >= tk:
            v = val
    return v

def lerp_path(keys, t, fn=ease):
    """keys: (t, value) piecewise eased"""
    if t <= keys[0][0]:
        return keys[0][1]
    for (a, va), (b, vb) in zip(keys, keys[1:]):
        if a <= t <= b:
            k = fn((t - a) / (b - a)) if b > a else 1
            if isinstance(va, tuple):
                return tuple(x + (y - x) * k for x, y in zip(va, vb))
            return va + (vb - va) * k
    return keys[-1][1]

def amp(who, f):
    a = TL["amp"][who]
    return a[f - 1] if 0 < f <= len(a) else 0.0

L = TL["lines"]

def rot(obj, deg):
    obj.rotation_euler = (0, -math.radians(deg), 0)
# ---------------------------------------------------------------- weather data
SP = {
    "idle":  dict(lean=0, head=0, sF=8, eF=10, sB=-8, eB=10),
    "tap":   dict(lean=6, head=2, sF=24, eF=-30, sB=-10, eB=12),
    "smug":  dict(lean=-3, head=-3, sF=8, eF=10, sB=-8, eB=10),
    "laughpose": dict(lean=-5, head=-6, sF=10, eF=12, sB=-10, eB=12),
    "wet":   dict(lean=2, head=-6, sF=4, eF=4, sB=-4, eB=4),
    "reach": dict(lean=4, head=2, sF=78, eF=6, sB=-8, eB=10),
    "towel": dict(lean=0, head=-2, sF=150, eF=30, sB=-8, eB=10),
    "hold":  dict(lean=-4, head=-2, sF=125, eF=0, sB=-14, eB=12),
    "slump": dict(lean=6, head=8, sF=118, eF=0, sB=-4, eB=6),
}
BP = {
    "hold":  dict(lean=0, head=0, aF=10, aB=-35),
    "point": dict(lean=2, head=6, aF=140, aB=-35),
    "under": dict(lean=0, head=0, aF=160, aB=-10),
    "give":  dict(lean=-6, head=-4, aF=160, aB=-82),
    "down":  dict(lean=0, head=2, aF=10, aB=-10),
}
SAM_POSE = [(0, SP["smug"]), (8.0, SP["idle"]), (8.9, SP["wet"]), (16.4, SP["reach"]), (17.25, SP["towel"]), (18.0, SP["wet"]),
            (20.55, SP["reach"]), (21.05, SP["hold"]), (23.1, SP["slump"])]
BOT_POSE = [(0, BP["hold"]), (4.3, BP["point"]), (7.75, BP["hold"]), (8.0, BP["under"]), (16.0, BP["give"]), (17.3, BP["under"]),
            (20.85, BP["give"]), (21.1, BP["down"])]
#            eyes, brows, mouth
SAM_MOOD = [(0, ("open", "up", "smile")), (8.6, ("wide", "up", "o")), (9.6, ("half", "sad", "frown")), (12.2, ("wide", "angry", "wide")),
            (14.2, ("half", "angry", "flat")), (16.3, ("half", "neutral", "flat")), (20.6, ("open", "up", "smile")),
            (21.8, ("wide", "up", "o")), (22.6, ("half", "sad", "frown"))]
BOT_MOOD = [(0, ("open", "line")), (4.3, ("flat", "line")), (7.7, ("happy", "line")), (8.4, ("open", "line")), (16.0, ("open", "small")),
            (17.4, ("open", "line")), (22.1, ("flat", "line"))]
BLINK_S = [3.0, 23.8]
BLINK_B = [2.2, 10.4, 19.2, 24.1]
SAM_X = [(0, -0.45), (20.55, -0.45), (20.85, -0.14), (21.05, -0.14), (21.65, -0.65)]
BOT_XY = (0.22, 0.50)
SHOTS = [(0.0, "wide"), (4.0, "botclock"), (8.0, "wide"), (12.0, "samclose"), (15.5, "medium"), (20.5, "wide2")]
SNAP = 7.6
TAPS = [0.35, 0.75, 1.15, 1.55, 2.6, 3.0]      # knee taps (front arm)
CLOUD_IN = 8.3
UMB_SWAP = 21.0                                  # Sam takes the umbrella
UNDER = (21.7, 22.15)                            # cloud slides under the umbrella edge
TOWEL = (17.25, 17.75)                           # towel flies from Bot's hand onto Sam's head

def shot_cam(kind, t, ts):
    k = t - ts
    if kind == "wide":
        return (0.0, -2.6 + 0.06 * k, 1.42), (0.0, 0.4, 1.28), 30
    if kind == "wide2":
        return (-0.20, -2.95 + 0.05 * k, 1.45), (-0.20, 0.4, 1.36), 34
    if kind == "botclock":
        return (0.50, -1.75 + 0.05 * k, 1.62), (0.50, 0.5, 1.60), 30
    if kind == "samclose":
        return (-0.42, -1.30 + 0.03 * k, 1.62), (-0.42, 0.4, 1.60), 30
    if kind == "medium":
        return (-0.10, -2.40 + 0.04 * k, 1.30), (-0.10, 0.4, 1.24), 30
    raise ValueError(kind)

def look(cam_loc, target):
    dx, dy, dz = (target[i] - cam_loc[i] for i in range(3))
    yaw = math.atan2(-dx, dy)
    pitch = math.atan2(dz, math.hypot(dx, dy))
    return (math.radians(90) + pitch, 0, yaw)

HIDE = (0.0001, 0.0001, 0.0001)
vis_keys = {}
def show(group, name, f):
    for n, o in group.items():
        vis_keys.setdefault(o, []).append((f, n == name))
def setvis(o, f, vis):
    vis_keys.setdefault(o, []).append((f, vis))

def human(H, f, t, poses, mood, blinks, who, xy, extra_head=0.0, walk=0.0):
    p = track(poses, t, 0.18)
    breath = math.sin(t * 2.2) * 1.5
    talk = amp(who, f) if who else 0.0
    H["root"].location = (xy[0], xy[1], 0.02 * abs(math.sin(walk)))
    H["root"].keyframe_insert("location", frame=f)
    H["hip"].location = (0, 0, 330 * PX + 0.004 * math.sin(t * 2.2))
    H["hip"].keyframe_insert("location", frame=f)
    rot(H["torso"], p["lean"] + breath * 0.4)
    nod = talk * 10 * math.sin(t * 9)
    rot(H["head"], p["head"] + nod + breath * 0.5 + extra_head)
    rot(H["shF"], p["sF"]); rot(H["elF"], p["eF"])
    rot(H["shB"], p["sB"]); rot(H["elB"], p["eB"])
    rot(H["legF"], 18 * math.sin(walk)); rot(H["legB"], -18 * math.sin(walk))
    for o in (H["torso"], H["head"], H["shF"], H["elF"], H["shB"], H["elB"], H["legF"], H["legB"]):
        o.keyframe_insert("rotation_euler", frame=f)
    eyes, brows, rest = step(mood, t)
    if any(b <= t < b + 0.13 for b in blinks):
        eyes = "blink"
    if talk > 0.02:
        mouth = "small" if talk < 0.08 else ("wide" if 12.0 < t < 15.0 else "open")
    else:
        mouth = rest
    show(H["face"]["eyes"], eyes, f)
    show(H["face"]["brows"], brows, f)
    show(H["face"]["mouth"], mouth, f)
    return p

def world_hand(cx, cz, sh_dx, sh_z, deg, length):
    """2D (x, z) of a hand for an arm at angle deg (rot() convention) from a shoulder"""
    a = math.radians(deg)
    return cx + sh_dx + length * math.sin(a), cz + sh_z - length * math.cos(a)

scene.view_layers[0].update()
bot_ant = 0.0
bot_ant_v = 0.0
for f in range(1, NF + 1):
    t = T(f)
    si = max(i for i, (ts, _) in enumerate(SHOTS) if t >= ts)
    ts, kind = SHOTS[si]
    # ---- Sam
    sx = lerp_path(SAM_X, t)
    walking = 21.1 <= t < 21.65 or 20.55 <= t < 20.85
    if kind == "botclock":
        sx = -1.6   # off frame while the camera is on Bot + clock
    p = human(SAM, f, t, SAM_POSE, SAM_MOOD, BLINK_S, "sam", (sx, 0.50), walk=(t * 18 if walking else 0.0))
    # knee taps in shot 1: front arm swings down-forward onto the knee
    tap = 0.0
    for a in TAPS:
        if a <= t < a + 0.32:
            tap = math.sin(math.pi * (t - a) / 0.32)
    if t < 3.6:
        rot(SAM["shF"], 10 + 22 * tap); rot(SAM["elF"], 12 - 40 * tap)
        rot(SAM["torso"], 2 + 6 * tap)
        SAM["shF"].keyframe_insert("rotation_euler", frame=f); SAM["elF"].keyframe_insert("rotation_euler", frame=f)
        SAM["torso"].keyframe_insert("rotation_euler", frame=f)
    # laugh shake (off-screen in shot 2, harmless)
    if 7.0 <= t < 7.6:
        rot(SAM["torso"], -5 + 3 * math.sin(t * 40)); SAM["torso"].keyframe_insert("rotation_euler", frame=f)
    # glasses / wet / towel on Sam's head
    gl = "glasses" if t < 12.0 else "glasses_crooked"
    show(GL, gl, f)
    setvis(WET, f, t >= 9.0)
    setvis(TWH, f, t >= TOWEL[1])
    # ---- Bot
    bp = track(BOT_POSE, t, 0.2)
    talk_b = amp("bot", f)
    BOT["root"].location = (BOT_XY[0], BOT_XY[1], 0.0)
    BOT["root"].keyframe_insert("location", frame=f)
    rot(BOT["body"], bp["lean"])
    rot(BOT["head"], bp["head"] + talk_b * 8 * math.sin(t * 8))
    rot(BOT["shF"], bp["aF"])
    rot(BOT["shB"], bp["aB"])
    force = -bot_ant * 60 - bot_ant_v * 6
    if abs(t - SNAP) < 1 / FPS or abs(t - UMB_SWAP) < 1 / FPS:
        bot_ant_v += 30
    bot_ant_v += force / FPS
    bot_ant += bot_ant_v / FPS
    rot(BOT["ant"], max(-30, min(30, bot_ant + talk_b * 6 * math.sin(t * 14))))
    for o in (BOT["body"], BOT["head"], BOT["shF"], BOT["shB"], BOT["ant"]):
        o.keyframe_insert("rotation_euler", frame=f)
    beyes, brest = step(BOT_MOOD, t)
    if any(b <= t < b + 0.12 for b in BLINK_B):
        beyes = "blink"
    bm = ("small" if talk_b < 0.1 else "open") if talk_b > 0.02 else brest
    show(BOT["face"]["eyes"], beyes, f)
    show(BOT["face"]["mouth"], bm, f)
    # ---- umbrellas: Bot holds it until the grab, then Sam. Kept upright (counter-rotate the arm)
    bot_has = t < UMB_SWAP
    ub_open = t >= 7.9
    UB_E.rotation_euler = (0, math.radians(bp["aF"]) + (math.radians(-34) if ub_open else math.radians(6)), 0)
    UB_E.scale = (0.78, 0.78, 0.78) if ub_open else (0.62, 0.62, 0.62)
    UB_E.keyframe_insert("rotation_euler", frame=f); UB_E.keyframe_insert("scale", frame=f)
    show(UB, "open" if (ub_open and bot_has) else None, f)
    UBC_E.rotation_euler = (0, math.radians(bp["aB"]) + math.radians(-6), 0)
    UBC_E.scale = (0.62, 0.62, 0.62)
    UBC_E.keyframe_insert("rotation_euler", frame=f); UBC_E.keyframe_insert("scale", frame=f)
    show(UBC, None if ub_open else "closed", f)
    sF = SAM["shF"].rotation_euler[1]; eF = SAM["elF"].rotation_euler[1]
    US_E.rotation_euler = (0, -(sF + eF) + math.radians(-29), 0)
    US_E.scale = (0.75, 0.75, 0.75)
    US_E.keyframe_insert("rotation_euler", frame=f); US_E.keyframe_insert("scale", frame=f)
    show(US, None if bot_has else "open", f)
    # ---- towel: in Bot's back hand 16.0-17.25, flies to Sam's head, then the draped sprite takes over
    if 15.9 <= t < TOWEL[1]:
        hx, hz = world_hand(BOT_XY[0], 0.0, -118 * PX, 330 * PX, bp["aB"], 0.30)
        hx, hz = hx - 0.02, hz + 0.04
        if t >= TOWEL[0]:
            k = ease((t - TOWEL[0]) / (TOWEL[1] - TOWEL[0]))
            tx, tz = sx, 1.72
            hx, hz = hx + (tx - hx) * k, hz + (tz - hz) * k + 0.25 * math.sin(math.pi * k)
        TWF.location = (hx, BOT_XY[1] - 0.06, hz)
    TWF.keyframe_insert("location", frame=f)
    setvis(bpy.data.objects["towel_folded_s"], f, 16.0 <= t < TOWEL[1])
    # ---- rain cloud: pops in over Sam at 8.3, follows him (lagging), slides under the umbrella at the end
    lag_x = lerp_path(SAM_X, t - 0.35)
    cz, cs, cy = 2.02, 0.70, 0.38
    if t >= 21.0:
        cz = 2.45                                          # pushed up above Sam's umbrella
    if t >= UNDER[0]:
        k = ease((t - UNDER[0]) / (UNDER[1] - UNDER[0]))
        cz = 2.45 + (1.84 - 2.45) * k - 0.12 * math.sin(math.pi * k)
        cs = 0.70 + (0.56 - 0.70) * k
        cy = 0.38 + (0.12 - 0.38) * k
        lag_x = lag_x + 0.32 * math.sin(math.pi * k) + 0.06 * k   # swoops out and back in, under the edge
    pop = back(min(1.0, max(0.0, (t - CLOUD_IN) / 0.3))) if t >= CLOUD_IN else 0.0001
    wob = 0.015 * math.sin(t * 3.1)
    CL.location = (lag_x + wob, cy, cz + 0.02 * math.sin(t * 2.3))
    CL.scale = (cs * pop, cs * pop, cs * pop)
    CL.keyframe_insert("location", frame=f); CL.keyframe_insert("scale", frame=f)
    raining = t >= CLOUD_IN + 0.25
    shield = 21.0 <= t < UNDER[0] + 0.25                 # rain hits the canopy only
    RAIN_E.scale = (1.0, 1.0, 0.45 if shield else 1.9)
    RAIN_E.keyframe_insert("scale", frame=f)
    for k2, o in RAIN.items():
        setvis(o, f, raining and k2 == (f // 2) % 3)
    # splash on Sam's head (or on the canopy while shielded)
    SPL.location = (sx + 0.02, 0.36, (2.06 if shield else 1.70))
    SPL.scale = (0.7 + 0.08 * math.sin(t * 20),) * 3
    SPL.keyframe_insert("location", frame=f); SPL.keyframe_insert("scale", frame=f)
    setvis(SPLS, f, raining)
    # ---- blanket flaps down at 8.0 (already landing at the cut)
    if t < 8.0:
        BLK.scale = HIDE
        BSK.scale = HIDE
    else:
        k = ease((t - 7.95) / 0.35)
        BLK.scale = (1.0, 0.35 + 0.65 * k, 1.0)
        BLK.location = (-0.42, 0.40, 0.25 * (1 - k))
        BSK.scale = (0.75, 0.75, 0.75)
    BLK.keyframe_insert("scale", frame=f); BLK.keyframe_insert("location", frame=f); BSK.keyframe_insert("scale", frame=f)
    # ---- clock: 2:59, minute hand snaps to 12 at SNAP
    mk = back(min(1.0, max(0.0, (t - SNAP) / 0.18)), 3.0) if t >= SNAP else 0.0
    CLK_M.rotation_euler = (0, math.radians(330 + 30 * mk), 0)
    CLK_H.rotation_euler = (0, math.radians(87.5 + 2.5 * mk), 0)
    CLK_M.keyframe_insert("rotation_euler", frame=f); CLK_H.keyframe_insert("rotation_euler", frame=f)
    # ---- camera
    loc, tgt, lens = shot_cam(kind, t, ts)
    cam.location = loc
    cam.rotation_euler = look(loc, tgt)
    camd.lens = lens
    camd.dof.aperture_fstop = 5.6
    camd.dof.focus_distance = math.dist(loc, (tgt[0], 0.5, tgt[2]))
    cam.keyframe_insert("location", frame=f)
    cam.keyframe_insert("rotation_euler", frame=f)
    camd.keyframe_insert("lens", frame=f)
    camd.dof.keyframe_insert("aperture_fstop", frame=f)
    camd.dof.keyframe_insert("focus_distance", frame=f)
    if f % 100 == 0:
        print("BBB baked frame", f, "/", NF)

for o, seq in vis_keys.items():
    last = None
    for f, vis in seq:
        if vis != last:
            o.hide_render = not vis
            o.hide_viewport = not vis
            o.keyframe_insert("hide_render", frame=f)
            o.keyframe_insert("hide_viewport", frame=f)
            last = vis
# ---------------------------------------------------------------- render settings
scene.render.engine = "CYCLES"
scene.cycles.samples = SAMPLES
scene.cycles.use_adaptive_sampling = True
scene.cycles.use_denoising = True
scene.cycles.max_bounces = 4
scene.cycles.diffuse_bounces = 2
scene.cycles.glossy_bounces = 2
scene.cycles.transparent_max_bounces = 32
scene.render.use_persistent_data = True
scene.view_settings.view_transform = "Standard"
scene.view_settings.look = "None"

def use_gpu():
    if CPU_ONLY:
        return "CPU"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        for kind in ("OPTIX", "CUDA", "HIP", "ONEAPI", "METAL"):
            try:
                prefs.compute_device_type = kind
            except Exception:
                continue
            prefs.get_devices()
            gpus = [d for d in prefs.devices if d.type == kind]
            if gpus:
                for d in prefs.devices:
                    d.use = d.type == kind
                scene.cycles.device = "GPU"
                try:
                    scene.cycles.denoiser = "OPTIX" if kind == "OPTIX" else "OPENIMAGEDENOISE"
                except Exception:
                    pass
                return kind + ": " + ", ".join(d.name for d in gpus)
    except Exception as e:
        print("GPU setup failed:", e)
    return "CPU"

print("BBB render device ->", use_gpu())

# ---------------------------------------------------------------- edit scene: 3D shot + captions + sound
edit.render.resolution_x, edit.render.resolution_y = 1080, 1920
edit.render.resolution_percentage = PCT
edit.render.fps = FPS
edit.frame_start, edit.frame_end = START, END
edit.view_settings.view_transform = "Standard"
se = edit.sequence_editor_create()
strips = se.strips if hasattr(se, "strips") else se.sequences
sc = strips.new_scene("shot", scene, 1, 1)
sc.frame_final_duration = NF
CAPDIR = os.path.join(HERE, "caps")
NOOV = os.environ.get("BBB_NOOV", "") == "1" or GREY
for c in ([] if NOOV else CAPS):
    f0 = int(round(c["start"] * FPS)) + 1
    f1 = max(f0 + 1, int(round(c["end"] * FPS)) + 1)
    im = strips.new_image("cap", os.path.join(CAPDIR, c["file"]), 3, f0)
    im.frame_final_duration = f1 - f0
    im.blend_type = "ALPHA_OVER"
    if c["first"]:
        try:
            tr = im.transform
            tr.origin = (0.5, 0.71)
            for df, s in ((0, 0.78), (2, 1.08), (4, 1.0)):
                tr.scale_x = tr.scale_y = s
                tr.keyframe_insert("scale_x", frame=f0 + df)
                tr.keyframe_insert("scale_y", frame=f0 + df)
        except Exception as e:
            print("caption pop skipped:", e)
OVS = json.load(open(os.path.join(HERE, "overlays.json")))
for c in ([] if NOOV else OVS):
    f0 = int(round(c["start"] * FPS)) + 1
    f1 = max(f0 + 1, int(round(c["end"] * FPS)) + 1)
    im = strips.new_image("ov", os.path.join(CAPDIR, c["file"]), c.get("ch", 4), f0)
    im.frame_final_duration = f1 - f0
    im.blend_type = "ALPHA_OVER"
    if c["file"].startswith("ov_photo"):   # slow push-in on the grandma photo
        try:
            tr = im.transform
            tr.origin = (0.5, 0.5)
            s0 = 1.0 + 0.05 * (c["start"] - 13.0) / 3.0
            s1 = 1.0 + 0.05 * (c["end"] - 13.0) / 3.0
            for fr, s in ((f0, s0), (f1 - 1, s1)):
                tr.scale_x = tr.scale_y = s
                tr.keyframe_insert("scale_x", frame=fr)
                tr.keyframe_insert("scale_y", frame=fr)
        except Exception as e:
            print("photo push-in skipped:", e)
snd = strips.new_sound("audio", os.path.join(HERE, "skit_audio.wav"), 5, 1)

def render_stills(frames):
    edit.render.image_settings.file_format = "PNG"
    for fr in frames:
        edit.frame_set(fr)
        edit.render.filepath = os.path.join(HERE, "still_%04d.png" % fr)
        bpy.ops.render.render(write_still=True, scene=edit.name)

if STILLS:
    render_stills([int(x) for x in STILLS.split(",")])
else:
    im = edit.render.image_settings
    try:
        im.media_type = "VIDEO"
    except Exception:
        pass
    im.file_format = "FFMPEG"
    ff = edit.render.ffmpeg
    ff.format = "MPEG4"
    ff.codec = "H264"
    ff.constant_rate_factor = "PERC_LOSSLESS"
    ff.audio_codec = "AAC"
    ff.audio_bitrate = 192
    ff.audio_channels = "STEREO"
    edit.render.filepath = os.path.join(HERE, OUTNAME)
    print("BBB rendering", END, "frames ->", edit.render.filepath)
    bpy.ops.render.render(animation=True, scene=edit.name)
    print("BBB DONE ->", edit.render.filepath)
