# Body Brain Bot - Sam vs Bot "The weather" skit (Blender 5.x)
# 2D cut-out characters with moving arms/legs/heads in a 3D room, camera cuts, depth of field,
# captions + sound added in Blender's video editor. Output: weather-1080x1920.mp4
import bpy, os, json, math

def find_here():
    cands = []
    try:
        cands.append(os.path.dirname(os.path.abspath(__file__)))
    except NameError:
        pass
    cands += [os.environ.get("BBB_DIR", ""), os.getcwd()]
    for c in cands:
        if c and os.path.exists(os.path.join(c, "timeline.json")):
            return c
    raise RuntimeError("Can't find the kit folder (timeline.json).")

HERE = find_here()
PARTS = os.path.join(HERE, "parts")
META = json.load(open(os.path.join(HERE, "parts.json")))
TL = json.load(open(os.path.join(HERE, "timeline.json")))
CAPS = json.load(open(os.path.join(HERE, "captions.json")))
FPS = TL["fps"]
NF = TL["frames"]

PCT = int(os.environ.get("BBB_PCT", "100"))
SAMPLES = int(os.environ.get("BBB_SAMPLES", "20"))
STILLS = os.environ.get("BBB_STILLS", "")
CPU_ONLY = os.environ.get("BBB_CPU", "") == "1"
OUTNAME = os.environ.get("BBB_OUT", "weather-1080x1920.mp4")
END = int(os.environ.get("BBB_END", NF))
PX = 0.0016   # metres per sprite pixel
GREY = os.environ.get("BBB_GREY", "") == "1"     # neutral blocking pass for Seedance @video (grey shapes, only arch lights coloured)
START = int(os.environ.get("BBB_START", "1"))

# ---------------------------------------------------------------- scene
edit = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
for s in list(bpy.data.scenes):
    if s != edit:
        bpy.data.scenes.remove(s)
for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.curves, bpy.data.lights, bpy.data.cameras, bpy.data.images):
    for b in list(coll):
        if b.users == 0:
            coll.remove(b)
if edit.sequence_editor:
    edit.sequence_editor_clear()
edit.name = "EDIT"
scene = bpy.data.scenes.new("SKIT")
scene.frame_start, scene.frame_end = START, END
scene.render.fps = FPS
scene.render.resolution_x, scene.render.resolution_y = 1080, 1920
scene.render.resolution_percentage = PCT

def link(o):
    scene.collection.objects.link(o)
    return o

def hexrgb(h):
    h = h.lstrip("#")
    c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return tuple(((x + 0.055) / 1.055) ** 2.4 if x > 0.04045 else x / 12.92 for x in c)

def mat(name, col, rough=0.6, emit=0.0, metal=0.0, keep=False):
    if GREY and not keep:
        col, emit, metal = "#34373D", 0.0, 0.0
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes.get("Principled BSDF")
    rgb = hexrgb(col) if isinstance(col, str) else col
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if emit:
        b.inputs["Emission Color"].default_value = (*rgb, 1)
        b.inputs["Emission Strength"].default_value = emit
    return m

def img_mat(path, strength=1.0, alpha=True):
    m = bpy.data.materials.new(os.path.basename(path))
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(path, check_existing=True)
    tex.extension = "CLIP"
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Strength"].default_value = strength
    if GREY:
        b = os.path.basename(path)
        g = 0.55 if b.startswith("bot") else (0.30 if b.startswith("off") else (0.85 if b.startswith(("sam", "shoes")) else 0.08))
        if b.startswith("shadow"):
            g = 0.0
        em.inputs["Color"].default_value = (g, g, g, 1)
    else:
        nt.links.new(tex.outputs["Color"], em.inputs["Color"])
    if alpha:
        tr = nt.nodes.new("ShaderNodeBsdfTransparent")
        mix = nt.nodes.new("ShaderNodeMixShader")
        nt.links.new(tex.outputs["Alpha"], mix.inputs[0])
        nt.links.new(tr.outputs[0], mix.inputs[1])
        nt.links.new(em.outputs[0], mix.inputs[2])
        nt.links.new(mix.outputs[0], out.inputs[0])
    else:
        nt.links.new(em.outputs[0], out.inputs[0])
    return m

def box(name, x0, x1, y0, y1, z0, z1, m, parent=None):
    me = bpy.data.meshes.new(name)
    v = [(x, y, z) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]
    f = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    me.from_pydata(v, [], f)
    me.materials.append(m)
    o = link(bpy.data.objects.new(name, me))
    if parent:
        o.parent = parent
    return o

def cyl(name, x, y, z0, z1, r, m, seg=24, r2=None):
    r2 = r if r2 is None else r2
    me = bpy.data.meshes.new(name)
    v, f = [], []
    for i in range(seg):
        a = 2 * math.pi * i / seg
        v += [(x + r * math.cos(a), y + r * math.sin(a), z0), (x + r2 * math.cos(a), y + r2 * math.sin(a), z1)]
    for i in range(seg):
        j = (i + 1) % seg
        f.append((2 * i, 2 * j, 2 * j + 1, 2 * i + 1))
    f.append(tuple(2 * i for i in range(seg))[::-1])
    f.append(tuple(2 * i + 1 for i in range(seg)))
    me.from_pydata(v, [], f)
    me.materials.append(m)
    for p in me.polygons:
        p.use_smooth = True
    return link(bpy.data.objects.new(name, me))

def sphere(name, loc, r, m):
    me = bpy.data.meshes.new(name)
    v, f, nu, nv = [], [], 16, 10
    for j in range(nv + 1):
        th = math.pi * j / nv
        for i in range(nu):
            ph = 2 * math.pi * i / nu
            v.append((r * math.sin(th) * math.cos(ph), r * math.sin(th) * math.sin(ph), r * math.cos(th)))
    for j in range(nv):
        for i in range(nu):
            a, b = j * nu + i, j * nu + (i + 1) % nu
            f.append((a, b, b + nu, a + nu))
    me.from_pydata(v, [], f)
    me.materials.append(m)
    for p in me.polygons:
        p.use_smooth = True
    o = link(bpy.data.objects.new(name, me))
    o.location = loc
    return o

def quad(name, w, h, m, cx=0.0, cz=0.0):
    """vertical quad in XZ plane facing -Y, centred at (cx, cz)"""
    me = bpy.data.meshes.new(name)
    me.from_pydata([(cx - w / 2, 0, cz - h / 2), (cx + w / 2, 0, cz - h / 2), (cx + w / 2, 0, cz + h / 2), (cx - w / 2, 0, cz + h / 2)], [], [(0, 1, 2, 3)])
    me.uv_layers.new()
    for i, c in enumerate([(0, 0), (1, 0), (1, 1), (0, 1)]):
        me.uv_layers[0].data[i].uv = c
    me.materials.append(m)
    o = link(bpy.data.objects.new(name, me))
    try:
        o.visible_shadow = False
    except Exception:
        pass
    return o

def empty(name, parent=None, loc=(0, 0, 0)):
    e = link(bpy.data.objects.new(name, None))
    e.empty_display_size = 0.05
    if parent:
        e.parent = parent
    e.location = loc
    return e

def sprite(part, parent, depth=0.0, name=None):
    """plane for a part, its pivot at the parent's origin"""
    m = META[part]
    w, h = m["w"] * PX, m["h"] * PX
    cx = (m["w"] / 2 - m["px"]) * PX
    cz = (m["py"] - m["h"] / 2) * PX
    o = quad(name or part, w, h, img_mat(os.path.join(PARTS, part + ".png")), cx, cz)
    o.parent = parent
    o.location = (0, depth, 0)
    return o
# ---------------------------------------------------------------- sunny living room
def emat(name, col, strength):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt2 = m.node_tree
    nt2.nodes.clear()
    o2 = nt2.nodes.new("ShaderNodeOutputMaterial")
    e2 = nt2.nodes.new("ShaderNodeEmission")
    e2.inputs["Color"].default_value = (*hexrgb(col), 1)
    e2.inputs["Strength"].default_value = strength
    nt2.links.new(e2.outputs[0], o2.inputs[0])
    return m
def checker(name, c1, c2, scale, rough=0.7):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    ck = nt.nodes.new("ShaderNodeTexChecker")
    ck.inputs["Scale"].default_value = scale
    ck.inputs["Color1"].default_value = (*hexrgb(c1), 1)
    ck.inputs["Color2"].default_value = (*hexrgb(c2), 1)
    tc = nt.nodes.new("ShaderNodeTexCoord")
    nt.links.new(tc.outputs["Object"], ck.inputs["Vector"])
    nt.links.new(ck.outputs["Color"], nt.nodes["Principled BSDF"].inputs["Base Color"])
    nt.nodes["Principled BSDF"].inputs["Roughness"].default_value = rough
    return m
GRASS = checker("grass", "#7CC562", "#74BD5B", 3.0, 0.9)
PATH = mat("path", "#E3C98E", 0.9)
PLAID = checker("plaid", "#E2434E", "#FFF4EC", 9.0, 0.85)
WOOD = mat("wood", "#A8744C", 0.5)
TRUNK = mat("trunk", "#8A5A3A", 0.7)
LEAF = mat("leaf", "#3E9A55", 0.6)
LEAF2 = mat("leaf2", "#52AE5E", 0.6)
box("ground", -12, 12, -8, 9, -0.05, 0, GRASS)
bgq = quad("park_bg", 22.0, 11.0, img_mat(os.path.join(PARTS, "park_bg.png"), 1.25, alpha=False), 0.0, 4.2)
bgq.location = (0, 9.0, 0)
bgr = quad("park_bg_rain", 22.0, 11.0, img_mat(os.path.join(PARTS, "park_bg_rain.png"), 1.0, alpha=False), 0.0, 4.2)
bgr.location = (0, 8.97, 0)
# path going back on the left (Sam runs along it)
me = bpy.data.meshes.new("path")
me.from_pydata([(-1.25, -1.5, 0.004), (-0.35, -1.5, 0.004), (-0.6, 8.0, 0.004), (-1.3, 8.0, 0.004)], [], [(0, 1, 2, 3)])
me.materials.append(PATH); link(bpy.data.objects.new("path", me))
# trees + bench
for (x, y, s) in ((-2.4, 3.2, 1.0), (2.3, 4.2, 1.2), (1.3, 6.5, 0.9)):
    cyl("trunk", x, y, 0, 1.6 * s, 0.12 * s, TRUNK, 16, 0.09 * s)
    for dx, dz, r, m in ((0, 2.0, 0.75, LEAF), (-0.45, 1.65, 0.5, LEAF2), (0.45, 1.7, 0.5, LEAF2), (0, 2.55, 0.5, LEAF2)):
        sphere("crown", (x + dx * s, y, dz * s), r * s, m)
box("bench_seat", 1.0, 2.2, 2.4, 2.75, 0.42, 0.48, WOOD)
box("bench_back", 1.0, 2.2, 2.72, 2.78, 0.5, 0.9, WOOD)
for x in (1.08, 2.12):
    box("bench_leg", x - 0.03, x + 0.03, 2.42, 2.73, 0, 0.42, mat("metal", "#55585F", 0.4))
# picnic blanket + basket (static from frame 0)
BLK = empty("blanket_e", None, (-0.42, 0.40, 0.0))
bl = box("blanket", -0.62, 0.62, -0.45, 0.45, 0.0, 0.012, PLAID)
bl.parent = BLK
BSK = empty("basket_e", None, (-1.05, 0.30, 0.012))
BSK.scale = (0.75, 0.75, 0.75)
sprite("basket", BSK, 0, "basket_s")

# ---------------------------------------------------------------- lights + world
world = scene.world or bpy.data.worlds.new("World")
scene.world = world
world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (*hexrgb("#BFE3FF"), 1)
world.node_tree.nodes["Background"].inputs[1].default_value = 1.0

def light(name, kind, loc, energy, color="#FFFFFF", size=1.0, rot=(0, 0, 0)):
    l = bpy.data.lights.new(name, kind)
    l.energy = energy
    l.color = hexrgb(color)
    if kind == "AREA":
        l.size = size
    if kind in ("POINT", "SPOT"):
        l.shadow_soft_size = size
    if kind == "SUN":
        l.angle = math.radians(8)
    o = link(bpy.data.objects.new(name, l))
    o.location = loc
    o.rotation_euler = rot
    return o

light("sun", "SUN", (0, 0, 5), 3.0, "#FFE7B5", 1.0, (math.radians(50), 0, math.radians(-160)))
light("key", "AREA", (-0.8, -3.0, 3.2), 320, "#FFF1DC", 3.5, (math.radians(45), 0, math.radians(-12)))
light("fill", "AREA", (2.5, -2.0, 2.4), 140, "#DDEBFF", 2.5, (math.radians(55), 0, math.radians(45)))


# ---------------------------------------------------------------- characters
def build_human(pre, leg, fores, mouths, scale=1.0, torso_part=None, name=None, head_part="sam_head"):
    root = empty((name or pre).upper())
    hip = empty(pre + "_hip", root, (0, 0, 330 * PX))
    legB = empty(pre + "_legB", hip, (-0.06, 0.03, 0))
    legF = empty(pre + "_legF", hip, (0.06, -0.03, 0))
    sprite(leg, legB, 0, pre + "_leg_b")
    sprite(leg, legF, 0, pre + "_leg_f")
    torso = empty(pre + "_torso_j", hip)
    sprite(torso_part or (pre + "_torso"), torso, 0)
    shB = empty(pre + "_shB", torso, (-90 * PX, 0.03, 245 * PX))
    shF = empty(pre + "_shF", torso, (90 * PX, -0.03, 245 * PX))
    neck = empty(pre + "_neck", torso, (0, -0.01, 290 * PX))
    P = {}
    for side, sh in (("B", shB), ("F", shF)):
        sprite("sam_upper", sh, 0, pre + "_upper_" + side)
        el = empty(pre + "_el" + side, sh, (0, 0, -100 * PX))
        sprite(fores[0], el, -0.002, pre + "_fore_" + side)
        P["sh" + side], P["el" + side] = sh, el
    head = empty(pre + "_head_j", neck)
    sprite(head_part, head, 0, pre + "_head")
    face = {}
    for grp, names, d in (("eyes", ["open", "blink", "wide", "half", "front"], -0.004),
                          ("brows", ["neutral", "up", "angry", "sad"], -0.006),
                          ("mouth", mouths, -0.005)):
        face[grp] = {n: sprite("sam_%s_%s" % (grp, n), head, d, "%s_%s_%s" % (pre, grp, n)) for n in names}
    root.scale = (scale, scale, scale)
    P.update(root=root, hip=hip, torso=torso, neck=neck, head=head, legB=legB, legF=legF, face=face, scale=scale)
    return P

def build_bot():
    root = empty("BOT")
    body = empty("bot_body_j", root)
    sprite("bot_body", body, 0)
    shB = empty("bot_shB", body, (-118 * PX, 0.03, 330 * PX))
    shF = empty("bot_shF", body, (118 * PX, -0.03, 330 * PX))
    sprite("bot_arm", shB, 0, "bot_arm_B")
    sprite("bot_arm", shF, 0, "bot_arm_F")
    neck = empty("bot_neck", body, (0, -0.01, 372 * PX))
    head = empty("bot_head_j", neck)
    sprite("bot_head", head, 0)
    ant = empty("bot_ant", head, (0, 0.004, 328 * PX))
    sprite("bot_antenna", ant, 0)
    face = {}
    for grp, names, d in (("eyes", ["open", "blink", "happy", "flat", "side", "think", "wink"], -0.004), ("mouth", ["line", "small", "open", "smirk", "wave"], -0.006)):
        face[grp] = {n: sprite("bot_%s_%s" % (grp, n), head, d) for n in names}
    face["screen"] = {n: sprite("bot_scr_" + n, head, -0.007) for n in ("259", "300", "304", "305")}
    return dict(root=root, body=body, shB=shB, shF=shF, neck=neck, head=head, ant=ant, face=face)

MOUTHS = ["smile", "flat", "frown", "small", "open", "wide", "o"]
SAM = build_human("sam", "sam_leg", ["sam_fore"], MOUTHS)
BOT = build_bot()
# Sam's extras on the head: glasses (straight / crooked), wet drops, towel
GL = {n: sprite("sam_" + n, SAM["head"], -0.008, "x_" + n) for n in ("glasses", "glasses_crooked")}
WET = sprite("sam_wet", SAM["head"], -0.009, "x_wet")
# umbrellas: Bot's (in his front hand) and Sam's (after the grab)
def umbrella(pre, arm_e, hand_px):
    e = empty(pre + "_umb_e", arm_e, (0, -0.012, -hand_px * PX))
    return e, {"closed": sprite("umb_closed", e, 0, pre + "_umb_closed"), "open": sprite("umb_open", e, 0, pre + "_umb_open")}
UB_E = empty("bot_umb_e", BOT["shF"], (0, -0.012, -190 * PX))   # open umbrella in Bot's raised front hand, beside his head
UB = {"open": sprite("umb_open", UB_E, 0, "bot_umb_open")}
UBC_E, UBC = umbrella("botc", BOT["shF"], 190)
US_E, US = umbrella("sam", SAM["elF"], 150)
# rain cloud: cloud + 3 rain frames + splash
CL = empty("cloud_e", None, (-0.45, 0.36, 2.15))
CLS = sprite("cloud", CL, 0, "cloud_s")
RAIN_E = empty("rain_e", CL, (0, 0.0, -0.02))
RAIN = {k: sprite("rain%d" % k, RAIN_E, 0, "rain_s%d" % k) for k in range(3)}
SPL = empty("splash_e", None, (0, 0, 0))
SPL.scale = (0.7, 0.7, 0.7)
SPLS = sprite("splash", SPL, 0, "splash_s")
# ---------------------------------------------------------------- camera
camd = bpy.data.cameras.new("cam")
camd.sensor_fit = "VERTICAL"
camd.sensor_height = 36
camd.dof.use_dof = True
cam = link(bpy.data.objects.new("cam", camd))
scene.camera = cam

# ---------------------------------------------------------------- camera
camd = bpy.data.cameras.new("cam")
camd.sensor_fit = "VERTICAL"
camd.sensor_height = 36
camd.dof.use_dof = True
cam = link(bpy.data.objects.new("cam", camd))
scene.camera = cam

# ---------------------------------------------------------------- animation helpers
def T(f):
    return (f - 1) / FPS

def ease(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)

def back(x, s=1.6):
    x = max(0.0, min(1.0, x))
    x -= 1
    return x * x * ((s + 1) * x + s) + 1

def track(keys, t, blend=0.22, fn=None):
    """keys: list of (time, value-dict). returns blended dict with overshoot"""
    fn = fn or back
    prev = keys[0][1]
    cur = keys[0][1]
    t0 = keys[0][0]
    for tk, v in keys:
        if t >= tk:
            prev, cur, t0 = cur, v, tk
    k = fn((t - t0) / blend)
    return {n: prev.get(n, 0) + (cur.get(n, 0) - prev.get(n, 0)) * k for n in cur}

def step(keys, t):
    v = keys[0][1]
    for tk, val in keys:
        if t >= tk:
            v = val
    return v

def lerp_path(keys, t, fn=ease):
    """keys: (t, value) piecewise eased"""
    if t <= keys[0][0]:
        return keys[0][1]
    for (a, va), (b, vb) in zip(keys, keys[1:]):
        if a <= t <= b:
            k = fn((t - a) / (b - a)) if b > a else 1
            if isinstance(va, tuple):
                return tuple(x + (y - x) * k for x, y in zip(va, vb))
            return va + (vb - va) * k
    return keys[-1][1]

def amp(who, f):
    a = TL["amp"][who]
    return a[f - 1] if 0 < f <= len(a) else 0.0

L = TL["lines"]

def rot(obj, deg):
    obj.rotation_euler = (0, -math.radians(deg), 0)
# full-frame rain sheets parented to the camera (near + far layer)
def cam_sheet(name, part, d):
    h = 1.2 * d * 1.15; w = 0.675 * d * 1.15
    me = bpy.data.meshes.new(name)
    me.from_pydata([(-w / 2, -h / 2, -d), (w / 2, -h / 2, -d), (w / 2, h / 2, -d), (-w / 2, h / 2, -d)], [], [(0, 1, 2, 3)])
    me.uv_layers.new()
    for i, c in enumerate([(0, 0), (1, 0), (1, 1), (0, 1)]):
        me.uv_layers[0].data[i].uv = c
    me.materials.append(img_mat(os.path.join(PARTS, part + ".png"), 1.0))
    o = link(bpy.data.objects.new(name, me)); o.parent = cam
    try:
        o.visible_shadow = False
    except Exception:
        pass
    return o
SHEETS = {k: [cam_sheet("rs_near%d" % k, "rainsheet%d" % k, 1.3), cam_sheet("rs_far%d" % k, "rainsheet%d" % ((k + 1) % 3), 3.2)] for k in range(3)}
LIGHTS = {n: bpy.data.objects[n].data for n in ("sun", "key", "fill")}
LBASE = {n: l.energy for n, l in LIGHTS.items()}

# ---------------------------------------------------------------- weather v4 (park) data
SP = {
    "idle":  dict(lean=0, head=0, sF=8, eF=10, sB=-8, eB=10),
    "smug":  dict(lean=-3, head=-3, sF=8, eF=10, sB=-8, eB=10),
    "wet":   dict(lean=2, head=-6, sF=4, eF=4, sB=-4, eB=4),
    "point": dict(lean=-4, head=-8, sF=118, eF=52, sB=-6, eB=6),
    "wring": dict(lean=6, head=6, sF=40, eF=88, sB=34, eB=90),
    "reach": dict(lean=4, head=2, sF=68, eF=6, sB=-8, eB=10),
    "hold":  dict(lean=-4, head=-2, sF=125, eF=0, sB=-14, eB=12),
    "run":   dict(lean=8, head=4, sF=125, eF=0, sB=-30, eB=20),
    "slump": dict(lean=6, head=8, sF=118, eF=0, sB=-4, eB=6),
}
BP = {
    "hold":  dict(lean=0, head=0, aF=35, aB=-10),
    "under": dict(lean=0, head=0, aF=140, aB=-10),
    "down":  dict(lean=0, head=2, aF=10, aB=-10),
}
SAM_POSE = [(0, SP["smug"]), (8.0, SP["idle"]), (8.9, SP["wet"]), (12.15, SP["point"]), (14.9, SP["wet"]), (15.6, SP["wring"]),
            (18.5, SP["reach"]), (19.0, SP["hold"]), (22.9, SP["slump"])]
BOT_POSE = [(0, BP["hold"]), (7.85, BP["under"]), (19.0, BP["down"])]
SAM_MOOD = [(0, ("open", "up", "smile")), (8.6, ("wide", "up", "o")), (9.6, ("half", "sad", "frown")), (12.15, ("wide", "angry", "wide")),
            (14.8, ("half", "angry", "flat")), (15.5, ("half", "sad", "frown")), (18.5, ("open", "up", "smile")),
            (22.2, ("wide", "up", "o")), (23.0, ("half", "neutral", "flat"))]
BOT_MOOD = [(0, ("open", "line")), (8.2, ("open", "line")), (22.3, ("flat", "line"))]
SCREEN = [(0, None), (4.2, "259"), (7.6, "300"), (8.0, None), (18.6, "304"), (22.15, "305")]
BLINK_S = [3.0, 18.2]
BLINK_B = [2.2, 10.4, 17.6]
SAM_P = [(0, (-0.45, 0.50)), (18.5, (-0.45, 0.50)), (18.85, (-0.20, 0.50)), (19.2, (-0.40, 0.50))]
BOT_XY = (0.22, 0.50)
SHOTS = [(0.0, "wide"), (4.0, "botclose"), (8.0, "wide"), (12.0, "samclose"), (15.5, "medium"), (18.5, "twist")]
SNAP = 7.6
TAPS = [0.35, 0.75, 1.15, 1.55, 2.6, 3.0]
RAIN_ON, RAIN_OFF = 7.65, 22.15
UMB_SWAP = 19.0

def shot_cam(kind, t, ts):
    k = t - ts
    if kind == "wide":
        return (0.0, -2.6 + 0.06 * k, 1.42), (0.0, 0.4, 1.28), 30
    if kind == "botclose":
        return (0.22, -1.30 + 0.04 * k, 1.02), (0.22, 0.5, 0.98), 30
    if kind == "samclose":
        return (-0.42, -1.30 + 0.03 * k, 1.62), (-0.42, 0.4, 1.66), 30
    if kind == "medium":
        return (-0.10, -2.40 + 0.04 * k, 1.30), (-0.10, 0.4, 1.24), 30
    if kind == "twist":
        a = ((-0.05, -2.75, 1.42), (-0.05, 0.4, 1.30))
        b = ((-0.30, -2.95, 1.45), (-0.30, 0.9, 1.30))
        c = ((0.02, -1.55, 1.12), (0.02, 1.0, 1.02))
        b = ((-0.02, -2.25, 1.32), (-0.02, 0.4, 1.24))
        u = ease((t - 22.25) / 0.6); p0, p1 = a, b
        lo = tuple(x + (y - x) * u for x, y in zip(p0[0], p1[0])); tg = tuple(x + (y - x) * u for x, y in zip(p0[1], p1[1]))
        return lo, tg, 30
    raise ValueError(kind)

def look(cam_loc, target):
    dx, dy, dz = (target[i] - cam_loc[i] for i in range(3))
    yaw = math.atan2(-dx, dy)
    pitch = math.atan2(dz, math.hypot(dx, dy))
    return (math.radians(90) + pitch, 0, yaw)

HIDE = (0.0001, 0.0001, 0.0001)
vis_keys = {}
def show(group, name, f):
    for n, o in group.items():
        vis_keys.setdefault(o, []).append((f, n == name))
def setvis(o, f, vis):
    vis_keys.setdefault(o, []).append((f, vis))

def human(H, f, t, poses, mood, blinks, who, xy, walk=0.0):
    p = track(poses, t, 0.18)
    breath = math.sin(t * 2.2) * 1.5
    talk = amp(who, f) if who else 0.0
    H["root"].location = (xy[0], xy[1], 0.025 * abs(math.sin(walk)))
    H["root"].keyframe_insert("location", frame=f)
    H["hip"].location = (0, 0, 330 * PX + 0.004 * math.sin(t * 2.2))
    H["hip"].keyframe_insert("location", frame=f)
    rot(H["torso"], p["lean"] + breath * 0.4)
    nod = talk * 10 * math.sin(t * 9)
    rot(H["head"], p["head"] + nod + breath * 0.5)
    rot(H["shF"], p["sF"]); rot(H["elF"], p["eF"])
    rot(H["shB"], p["sB"] + (25 * math.sin(walk) if walk else 0)); rot(H["elB"], p["eB"])
    rot(H["legF"], 22 * math.sin(walk)); rot(H["legB"], -22 * math.sin(walk))
    for o in (H["torso"], H["head"], H["shF"], H["elF"], H["shB"], H["elB"], H["legF"], H["legB"]):
        o.keyframe_insert("rotation_euler", frame=f)
    eyes, brows, rest = step(mood, t)
    if any(b <= t < b + 0.13 for b in blinks):
        eyes = "blink"
    if talk > 0.02:
        mouth = "small" if talk < 0.08 else ("wide" if 12.0 < t < 15.0 else "open")
    else:
        mouth = rest
    show(H["face"]["eyes"], eyes, f)
    show(H["face"]["brows"], brows, f)
    show(H["face"]["mouth"], mouth, f)
    return p

scene.view_layers[0].update()
bot_ant = 0.0
bot_ant_v = 0.0
for f in range(1, NF + 1):
    t = T(f)
    si = max(i for i, (ts, _) in enumerate(SHOTS) if t >= ts)
    ts, kind = SHOTS[si]
    # ---- Sam
    sx, sy = lerp_path(SAM_P, t)
    if kind == "botclose":
        sx = -1.6   # off frame while the camera is on Bot
    walking = 18.5 <= t < 18.85 or 19.0 <= t < 19.2
    wspeed = 20
    human(SAM, f, t, SAM_POSE, SAM_MOOD, BLINK_S, "sam", (sx, sy), walk=(t * wspeed if walking else 0.0))
    tap = 0.0
    for a in TAPS:
        if a <= t < a + 0.32:
            tap = math.sin(math.pi * (t - a) / 0.32)
    if t < 3.6:
        kk = min(1.0, (3.6 - t) / 0.35); rot(SAM["shF"], 8 + kk * (16 + 8 * tap)); rot(SAM["elF"], 10 - kk * (10 + 4 * tap)); rot(SAM["torso"], -3 - kk * (4 + 3 * tap)); rot(SAM["legF"], 28 * kk); SAM["legF"].keyframe_insert("rotation_euler", frame=f)
        SAM["shF"].keyframe_insert("rotation_euler", frame=f); SAM["elF"].keyframe_insert("rotation_euler", frame=f)
        SAM["torso"].keyframe_insert("rotation_euler", frame=f)
    if 15.6 <= t < 19.6:   # wring the hoodie: small twisting
        w = 10 * math.sin(t * 9)
        rot(SAM["elF"], 88 + w); rot(SAM["elB"], 90 - w)
        SAM["elF"].keyframe_insert("rotation_euler", frame=f); SAM["elB"].keyframe_insert("rotation_euler", frame=f)
    show(GL, "glasses" if t < 12.0 else "glasses_crooked", f)
    setvis(WET, f, t >= 8.3)
    # ---- Bot
    bp = track(BOT_POSE, t, 0.2)
    talk_b = amp("bot", f)
    BOT["root"].location = (BOT_XY[0], BOT_XY[1], 0.0)
    BOT["root"].keyframe_insert("location", frame=f)
    rot(BOT["body"], bp["lean"])
    rot(BOT["head"], bp["head"] + talk_b * 8 * math.sin(t * 8))
    rot(BOT["shF"], bp["aF"])
    rot(BOT["shB"], bp["aB"])
    force = -bot_ant * 60 - bot_ant_v * 6
    if abs(t - SNAP) < 1 / FPS or abs(t - UMB_SWAP) < 1 / FPS or abs(t - RAIN_OFF) < 1 / FPS:
        bot_ant_v += 30
    bot_ant_v += force / FPS
    bot_ant += bot_ant_v / FPS
    rot(BOT["ant"], max(-30, min(30, bot_ant + talk_b * 6 * math.sin(t * 14))))
    for o in (BOT["body"], BOT["head"], BOT["shF"], BOT["shB"], BOT["ant"]):
        o.keyframe_insert("rotation_euler", frame=f)
    scr = step(SCREEN, t)
    show(BOT["face"]["screen"], scr, f)
    beyes, brest = step(BOT_MOOD, t)
    if any(b <= t < b + 0.12 for b in BLINK_B):
        beyes = "blink"
    bm = ("small" if talk_b < 0.1 else "open") if talk_b > 0.02 else brest
    show(BOT["face"]["eyes"], None if scr else beyes, f)
    show(BOT["face"]["mouth"], None if scr else bm, f)
    # ---- umbrellas: closed in Bot's left hand (0-7.9), open straight up behind his head (7.9-20.3), then Sam's
    UBC_E.rotation_euler = (0, math.radians(bp["aF"]) + math.radians(6), 0)
    UBC_E.scale = (0.62, 0.62, 0.62)
    UBC_E.keyframe_insert("rotation_euler", frame=f); UBC_E.keyframe_insert("scale", frame=f)
    show(UBC, "closed" if t < 7.85 else None, f)
    op = back(min(1.0, max(0.0, (t - 7.85) / 0.25)))
    UB_E.scale = (0.80 * max(op, 0.0001), 0.80, 0.80)
    UB_E.keyframe_insert("scale", frame=f)
    UB_E.rotation_euler = (0, math.radians(bp["aF"]) - math.radians(10), 0); UB_E.keyframe_insert("rotation_euler", frame=f)
    show(UB, "open" if 7.85 <= t < UMB_SWAP else None, f)
    sF = SAM["shF"].rotation_euler[1]; eF = SAM["elF"].rotation_euler[1]
    US_E.rotation_euler = (0, -(sF + eF) + math.radians(-4), 0)
    US_E.scale = (0.75, 0.75, 0.75)
    US_E.keyframe_insert("rotation_euler", frame=f); US_E.keyframe_insert("scale", frame=f)
    show(US, "open" if t >= UMB_SWAP else None, f)
    # ---- weather: sunny -> pouring at 3:00 -> sunny at 3:05
    raining = RAIN_ON <= t < RAIN_OFF
    setvis(bgq, f, not raining); setvis(bgr, f, raining)
    for k2, (o1, o2) in SHEETS.items():
        on = raining and k2 == (f // 2) % 3
        setvis(o1, f, on); setvis(o2, f, on)
    for n, l in LIGHTS.items():
        l.energy = LBASE[n] * (0.35 if raining else 1.0)
        l.keyframe_insert("energy", frame=f)
    world.node_tree.nodes["Background"].inputs[1].default_value = 0.45 if raining else 1.0
    world.node_tree.nodes["Background"].inputs[1].keyframe_insert("default_value", frame=f)
    CL.scale = HIDE; CL.keyframe_insert("scale", frame=f)
    for o in RAIN.values():
        setvis(o, f, False)
    shield = t >= UMB_SWAP
    SPL.location = (sx + 0.02, sy - 0.14, 1.70)
    SPL.scale = (0.7 + 0.08 * math.sin(t * 20),) * 3
    SPL.keyframe_insert("location", frame=f); SPL.keyframe_insert("scale", frame=f)
    setvis(SPLS, f, False)
    # ---- camera
    loc, tgt, lens = shot_cam(kind, t, ts)
    cam.location = loc
    cam.rotation_euler = look(loc, tgt)
    camd.lens = lens
    camd.dof.aperture_fstop = 5.6
    camd.dof.focus_distance = math.dist(loc, (tgt[0], 0.5, tgt[2]))
    cam.keyframe_insert("location", frame=f)
    cam.keyframe_insert("rotation_euler", frame=f)
    camd.keyframe_insert("lens", frame=f)
    camd.dof.keyframe_insert("aperture_fstop", frame=f)
    camd.dof.keyframe_insert("focus_distance", frame=f)
    if f % 100 == 0:
        print("BBB baked frame", f, "/", NF)

for o, seq in vis_keys.items():
    last = None
    for f, vis in seq:
        if vis != last:
            o.hide_render = not vis
            o.hide_viewport = not vis
            o.keyframe_insert("hide_render", frame=f)
            o.keyframe_insert("hide_viewport", frame=f)
            last = vis
# ---------------------------------------------------------------- render settings
scene.render.engine = "CYCLES"
scene.cycles.samples = SAMPLES
scene.cycles.use_adaptive_sampling = True
scene.cycles.use_denoising = True
scene.cycles.max_bounces = 4
scene.cycles.diffuse_bounces = 2
scene.cycles.glossy_bounces = 2
scene.cycles.transparent_max_bounces = 32
scene.render.use_persistent_data = True
scene.view_settings.view_transform = "Standard"
scene.view_settings.look = "None"

def use_gpu():
    if CPU_ONLY:
        return "CPU"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        for kind in ("OPTIX", "CUDA", "HIP", "ONEAPI", "METAL"):
            try:
                prefs.compute_device_type = kind
            except Exception:
                continue
            prefs.get_devices()
            gpus = [d for d in prefs.devices if d.type == kind]
            if gpus:
                for d in prefs.devices:
                    d.use = d.type == kind
                scene.cycles.device = "GPU"
                try:
                    scene.cycles.denoiser = "OPENIMAGEDENOISE"; scene.cycles.denoising_use_gpu = True
                except Exception:
                    pass
                return kind + ": " + ", ".join(d.name for d in gpus)
    except Exception as e:
        print("GPU setup failed:", e)
    return "CPU"

print("BBB render device ->", use_gpu())

# ---------------------------------------------------------------- edit scene: 3D shot + captions + sound
edit.render.resolution_x, edit.render.resolution_y = 1080, 1920
edit.render.resolution_percentage = PCT
edit.render.fps = FPS
edit.frame_start, edit.frame_end = START, END
edit.view_settings.view_transform = "Standard"
se = edit.sequence_editor_create()
strips = se.strips if hasattr(se, "strips") else se.sequences
sc = strips.new_scene("shot", scene, 1, 1)
sc.frame_final_duration = NF
CAPDIR = os.path.join(HERE, "caps")
NOOV = os.environ.get("BBB_NOOV", "") == "1" or GREY
for c in ([] if NOOV else CAPS):
    f0 = int(round(c["start"] * FPS)) + 1
    f1 = max(f0 + 1, int(round(c["end"] * FPS)) + 1)
    im = strips.new_image("cap", os.path.join(CAPDIR, c["file"]), 3, f0)
    im.frame_final_duration = f1 - f0
    im.blend_type = "ALPHA_OVER"
    if c["first"]:
        try:
            tr = im.transform
            tr.origin = (0.5, 0.71)
            for df, s in ((0, 0.78), (2, 1.08), (4, 1.0)):
                tr.scale_x = tr.scale_y = s
                tr.keyframe_insert("scale_x", frame=f0 + df)
                tr.keyframe_insert("scale_y", frame=f0 + df)
        except Exception as e:
            print("caption pop skipped:", e)
OVS = json.load(open(os.path.join(HERE, "overlays.json")))
for c in ([] if NOOV else OVS):
    f0 = int(round(c["start"] * FPS)) + 1
    f1 = max(f0 + 1, int(round(c["end"] * FPS)) + 1)
    im = strips.new_image("ov", os.path.join(CAPDIR, c["file"]), c.get("ch", 4), f0)
    im.frame_final_duration = f1 - f0
    im.blend_type = "ALPHA_OVER"
    if c["file"].startswith("ov_photo"):   # slow push-in on the grandma photo
        try:
            tr = im.transform
            tr.origin = (0.5, 0.5)
            s0 = 1.0 + 0.05 * (c["start"] - 13.0) / 3.0
            s1 = 1.0 + 0.05 * (c["end"] - 13.0) / 3.0
            for fr, s in ((f0, s0), (f1 - 1, s1)):
                tr.scale_x = tr.scale_y = s
                tr.keyframe_insert("scale_x", frame=fr)
                tr.keyframe_insert("scale_y", frame=fr)
        except Exception as e:
            print("photo push-in skipped:", e)
snd = strips.new_sound("audio", os.path.join(HERE, "skit_audio.wav"), 5, 1)

def render_stills(frames):
    edit.render.image_settings.file_format = "PNG"
    for fr in frames:
        edit.frame_set(fr)
        edit.render.filepath = os.path.join(HERE, "still_%04d.png" % fr)
        bpy.ops.render.render(write_still=True, scene=edit.name)

if STILLS:
    render_stills([int(x) for x in STILLS.split(",")])
else:
    im = edit.render.image_settings
    try:
        im.media_type = "VIDEO"
    except Exception:
        pass
    im.file_format = "FFMPEG"
    ff = edit.render.ffmpeg
    ff.format = "MPEG4"
    ff.codec = "H264"
    ff.constant_rate_factor = "PERC_LOSSLESS"
    ff.audio_codec = "AAC"
    ff.audio_bitrate = 192
    ff.audio_channels = "STEREO"
    edit.render.filepath = os.path.join(HERE, OUTNAME)
    print("BBB rendering", END, "frames ->", edit.render.filepath)
    bpy.ops.render.render(animation=True, scene=edit.name)
    print("BBB DONE ->", edit.render.filepath)
