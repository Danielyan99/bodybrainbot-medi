# Body Brain Bot - Sam vs Bot "Airport scanner" animatic (Blender 5.x)
# 2D cut-out characters with moving arms/legs/heads in a 3D room, camera cuts, depth of field,
# captions + sound added in Blender's video editor. Output: airport-scanner-1080x1920.mp4
import bpy, os, json, math

def find_here():
    cands = []
    try:
        cands.append(os.path.dirname(os.path.abspath(__file__)))
    except NameError:
        pass
    cands += [os.environ.get("BBB_DIR", ""), os.getcwd()]
    for c in cands:
        if c and os.path.exists(os.path.join(c, "timeline.json")):
            return c
    raise RuntimeError("Can't find the kit folder (timeline.json).")

HERE = find_here()
PARTS = os.path.join(HERE, "parts")
META = json.load(open(os.path.join(HERE, "parts.json")))
TL = json.load(open(os.path.join(HERE, "timeline.json")))
CAPS = json.load(open(os.path.join(HERE, "captions.json")))
FPS = TL["fps"]
NF = TL["frames"]

PCT = int(os.environ.get("BBB_PCT", "100"))
SAMPLES = int(os.environ.get("BBB_SAMPLES", "20"))
STILLS = os.environ.get("BBB_STILLS", "")
CPU_ONLY = os.environ.get("BBB_CPU", "") == "1"
OUTNAME = os.environ.get("BBB_OUT", "airport-scanner-1080x1920.mp4")
END = int(os.environ.get("BBB_END", NF))
PX = 0.0016   # metres per sprite pixel
GREY = os.environ.get("BBB_GREY", "") == "1"     # neutral blocking pass for Seedance @video (grey shapes, only arch lights coloured)
START = int(os.environ.get("BBB_START", "1"))

# ---------------------------------------------------------------- scene
edit = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
for s in list(bpy.data.scenes):
    if s != edit:
        bpy.data.scenes.remove(s)
for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.curves, bpy.data.lights, bpy.data.cameras, bpy.data.images):
    for b in list(coll):
        if b.users == 0:
            coll.remove(b)
if edit.sequence_editor:
    edit.sequence_editor_clear()
edit.name = "EDIT"
scene = bpy.data.scenes.new("SKIT")
scene.frame_start, scene.frame_end = START, END
scene.render.fps = FPS
scene.render.resolution_x, scene.render.resolution_y = 1080, 1920
scene.render.resolution_percentage = PCT

def link(o):
    scene.collection.objects.link(o)
    return o

def hexrgb(h):
    h = h.lstrip("#")
    c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return tuple(((x + 0.055) / 1.055) ** 2.4 if x > 0.04045 else x / 12.92 for x in c)

def mat(name, col, rough=0.6, emit=0.0, metal=0.0, keep=False):
    if GREY and not keep:
        col, emit, metal = "#34373D", 0.0, 0.0
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes.get("Principled BSDF")
    rgb = hexrgb(col) if isinstance(col, str) else col
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if emit:
        b.inputs["Emission Color"].default_value = (*rgb, 1)
        b.inputs["Emission Strength"].default_value = emit
    return m

def img_mat(path, strength=1.0, alpha=True):
    m = bpy.data.materials.new(os.path.basename(path))
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(path, check_existing=True)
    tex.extension = "CLIP"
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Strength"].default_value = strength
    if GREY:
        b = os.path.basename(path)
        g = 0.55 if b.startswith("bot") else (0.30 if b.startswith("off") else (0.85 if b.startswith(("sam", "shoes")) else 0.08))
        if b.startswith("shadow"):
            g = 0.0
        em.inputs["Color"].default_value = (g, g, g, 1)
    else:
        nt.links.new(tex.outputs["Color"], em.inputs["Color"])
    if alpha:
        tr = nt.nodes.new("ShaderNodeBsdfTransparent")
        mix = nt.nodes.new("ShaderNodeMixShader")
        nt.links.new(tex.outputs["Alpha"], mix.inputs[0])
        nt.links.new(tr.outputs[0], mix.inputs[1])
        nt.links.new(em.outputs[0], mix.inputs[2])
        nt.links.new(mix.outputs[0], out.inputs[0])
    else:
        nt.links.new(em.outputs[0], out.inputs[0])
    return m

def box(name, x0, x1, y0, y1, z0, z1, m, parent=None):
    me = bpy.data.meshes.new(name)
    v = [(x, y, z) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]
    f = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    me.from_pydata(v, [], f)
    me.materials.append(m)
    o = link(bpy.data.objects.new(name, me))
    if parent:
        o.parent = parent
    return o

def cyl(name, x, y, z0, z1, r, m, seg=24, r2=None):
    r2 = r if r2 is None else r2
    me = bpy.data.meshes.new(name)
    v, f = [], []
    for i in range(seg):
        a = 2 * math.pi * i / seg
        v += [(x + r * math.cos(a), y + r * math.sin(a), z0), (x + r2 * math.cos(a), y + r2 * math.sin(a), z1)]
    for i in range(seg):
        j = (i + 1) % seg
        f.append((2 * i, 2 * j, 2 * j + 1, 2 * i + 1))
    f.append(tuple(2 * i for i in range(seg))[::-1])
    f.append(tuple(2 * i + 1 for i in range(seg)))
    me.from_pydata(v, [], f)
    me.materials.append(m)
    for p in me.polygons:
        p.use_smooth = True
    return link(bpy.data.objects.new(name, me))

def sphere(name, loc, r, m):
    me = bpy.data.meshes.new(name)
    v, f, nu, nv = [], [], 16, 10
    for j in range(nv + 1):
        th = math.pi * j / nv
        for i in range(nu):
            ph = 2 * math.pi * i / nu
            v.append((r * math.sin(th) * math.cos(ph), r * math.sin(th) * math.sin(ph), r * math.cos(th)))
    for j in range(nv):
        for i in range(nu):
            a, b = j * nu + i, j * nu + (i + 1) % nu
            f.append((a, b, b + nu, a + nu))
    me.from_pydata(v, [], f)
    me.materials.append(m)
    for p in me.polygons:
        p.use_smooth = True
    o = link(bpy.data.objects.new(name, me))
    o.location = loc
    return o

def quad(name, w, h, m, cx=0.0, cz=0.0):
    """vertical quad in XZ plane facing -Y, centred at (cx, cz)"""
    me = bpy.data.meshes.new(name)
    me.from_pydata([(cx - w / 2, 0, cz - h / 2), (cx + w / 2, 0, cz - h / 2), (cx + w / 2, 0, cz + h / 2), (cx - w / 2, 0, cz + h / 2)], [], [(0, 1, 2, 3)])
    me.uv_layers.new()
    for i, c in enumerate([(0, 0), (1, 0), (1, 1), (0, 1)]):
        me.uv_layers[0].data[i].uv = c
    me.materials.append(m)
    o = link(bpy.data.objects.new(name, me))
    try:
        o.visible_shadow = False
    except Exception:
        pass
    return o

def empty(name, parent=None, loc=(0, 0, 0)):
    e = link(bpy.data.objects.new(name, None))
    e.empty_display_size = 0.05
    if parent:
        e.parent = parent
    e.location = loc
    return e

def sprite(part, parent, depth=0.0, name=None):
    """plane for a part, its pivot at the parent's origin"""
    m = META[part]
    w, h = m["w"] * PX, m["h"] * PX
    cx = (m["w"] / 2 - m["px"]) * PX
    cz = (m["py"] - m["h"] / 2) * PX
    o = quad(name or part, w, h, img_mat(os.path.join(PARTS, part + ".png")), cx, cz)
    o.parent = parent
    o.location = (0, depth, 0)
    return o
# ---------------------------------------------------------------- airport security checkpoint
TILE = bpy.data.materials.new("tile")
TILE.use_nodes = True
nt = TILE.node_tree
chk = nt.nodes.new("ShaderNodeTexChecker")
chk.inputs["Scale"].default_value = 9.0
c1, c2 = ("#34373D", "#34373D") if GREY else ("#D9DCE2", "#C7CBD3")
chk.inputs["Color1"].default_value = (*hexrgb(c1), 1)
chk.inputs["Color2"].default_value = (*hexrgb(c2), 1)
nt.links.new(chk.outputs["Color"], nt.nodes["Principled BSDF"].inputs["Base Color"])
nt.nodes["Principled BSDF"].inputs["Roughness"].default_value = 0.25
WALLM = mat("wall", "#E9ECF1", 0.8)
WALLD = mat("wall_dark", "#5B6578", 0.7)
ARCH = mat("arch", "#C9CED6", 0.4)
ARCHD = mat("arch_dark", "#3A404C", 0.5)
BELT = mat("belt", "#2A2D34", 0.6)
TRAY = mat("tray", "#7E8794", 0.5)
POST = mat("post", "#B8BEC7", 0.25, metal=0.7)
ROPE = mat("rope", "#2F5BD2", 0.6)
SIGNM = mat("sign", "#1E2633", 0.5)
SIGNT = mat("signtxt", "#FFD43B", 0.5, emit=1.5)
LOFF = mat("light_off", "#4A505C", 0.4, keep=True)
def emat(name, col, strength):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt2 = m.node_tree
    nt2.nodes.clear()
    o2 = nt2.nodes.new("ShaderNodeOutputMaterial")
    e2 = nt2.nodes.new("ShaderNodeEmission")
    e2.inputs["Color"].default_value = (*hexrgb(col), 1)
    e2.inputs["Strength"].default_value = strength
    nt2.links.new(e2.outputs[0], o2.inputs[0])
    return m
LGRN = emat("light_green", "#22E05A", 1.6)
LRED = emat("light_red", "#FF2A1F", 1.6)

WY = 3.4
box("floor", -5, 5, -7, 6, -0.05, 0, TILE)
box("wall_back", -5, 5, WY, WY + 0.1, 0, 4.0, WALLM)
box("wall_low", -5, 5, WY - 0.05, WY, 0, 0.45, WALLD)
sky = quad("sky", 5.6, 3.6, img_mat(os.path.join(PARTS, "sky.png"), 1.0, alpha=False), 0.0, 2.25)
sky.location = (0, WY - 0.01, 0)
for x in (-2.8, -1.4, 0.0, 1.4, 2.8):
    box("mull", x - 0.04, x + 0.04, WY - 0.06, WY - 0.01, 0.45, 4.0, WALLD)
box("win_top", -5, 5, WY - 0.06, WY - 0.01, 3.95, 4.0, WALLD)
# walk-through metal detector arch (opening faces the camera, centre x=0, y=0.30)
AY0, AY1 = 0.20, 0.42
box("arch_l", -0.66, -0.50, AY0, AY1, 0, 2.15, ARCH)
box("arch_r", 0.50, 0.66, AY0, AY1, 0, 2.15, ARCH)
box("arch_top", -0.66, 0.66, AY0, AY1, 2.15, 2.36, ARCH)
box("arch_foot_l", -0.72, -0.44, AY0 - 0.06, AY1 + 0.06, 0, 0.05, ARCHD)
box("arch_foot_r", 0.44, 0.72, AY0 - 0.06, AY1 + 0.06, 0, 0.05, ARCHD)
box("lamp_base", -0.31, 0.31, AY0 + 0.02, AY1 - 0.02, 2.36, 2.40, ARCHD)
LAMPS = {}
for i, (n, m) in enumerate((("off", LOFF), ("green", LGRN), ("red", LRED))):
    o = box("lamp_" + n, -0.28, 0.28, AY0 + 0.03 - 0.002 * i, AY1 - 0.03, 2.40, 2.64, m)
    LAMPS[n] = o
STRIPS = {}
for i, (n, m) in enumerate((("off", LOFF), ("green", LGRN), ("red", LRED))):
    a = box("strip_l_" + n, -0.53, -0.505, AY0 - 0.003 - 0.002 * i, AY1, 0.15, 2.05, m)
    b = box("strip_r_" + n, 0.505, 0.53, AY0 - 0.003 - 0.002 * i, AY1, 0.15, 2.05, m)
    STRIPS[n] = a
    STRIPS[n + "_r"] = b
GLOW = {}
for n, col in (("green", "#3DFF7A"), ("red", "#FF3B30")):
    l = bpy.data.lights.new("glow_" + n, "POINT")
    l.color = hexrgb(col)
    l.shadow_soft_size = 0.3
    l.energy = 0
    o = link(bpy.data.objects.new("glow_" + n, l))
    o.location = (0, AY0 - 0.25, 2.3)
    GLOW[n] = l
# x-ray belt with trays (left)
box("belt_body", -3.2, -0.95, 0.05, 0.75, 0, 0.72, BELT)
box("belt_top", -3.2, -0.95, 0.08, 0.72, 0.72, 0.76, mat("belttop", "#4A4F59", 0.5))
box("xray", -2.6, -1.6, 0.0, 0.8, 0.72, 1.55, ARCH)
box("xray_mouth", -2.55, -1.65, -0.005, 0.0, 0.76, 1.15, BELT)
for x in (-1.5, -1.05):
    box("tray", x - 0.2, x + 0.2, 0.2, 0.6, 0.76, 0.84, TRAY)
# queue posts + blue belt (right back)
for (x, y) in ((1.1, 1.3), (2.1, 1.3), (2.1, 2.4), (1.1, 2.4)):
    cyl("post", x, y, 0, 0.95, 0.025, POST, 12)
    cyl("post_base", x, y, 0, 0.03, 0.14, POST, 20)
box("rope1", 1.1, 2.1, 1.29, 1.31, 0.86, 0.92, ROPE)
box("rope2", 2.09, 2.11, 1.3, 2.4, 0.86, 0.92, ROPE)
box("rope3", 1.1, 2.1, 2.39, 2.41, 0.86, 0.92, ROPE)

# ---------------------------------------------------------------- lights + world
world = scene.world or bpy.data.worlds.new("World")
scene.world = world
world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (*hexrgb("#DDE6F2"), 1)
world.node_tree.nodes["Background"].inputs[1].default_value = 0.05 if GREY else 0.5

def light(name, kind, loc, energy, color="#FFFFFF", size=1.0, rot=(0, 0, 0)):
    l = bpy.data.lights.new(name, kind)
    l.energy = energy
    l.color = hexrgb(color)
    if kind == "AREA":
        l.size = size
    if kind == "POINT":
        l.shadow_soft_size = size
    o = link(bpy.data.objects.new(name, l))
    o.location = loc
    o.rotation_euler = rot
    return o

light("key", "AREA", (-0.8, -3.0, 3.4), 420, "#FFF4E6", 3.5, (math.radians(45), 0, math.radians(-12)))
light("fill", "AREA", (2.5, -2.0, 2.4), 140, "#DCE8FF", 2.5, (math.radians(55), 0, math.radians(45)))
light("ceiling", "AREA", (0, 1.0, 3.9), 300, "#FFFFFF", 4.0, (0, 0, 0))
light("window", "AREA", (0, WY - 0.4, 2.2), 120, "#BFD8FF", 4.0, (math.radians(-90), 0, 0))

# ---------------------------------------------------------------- characters
def build_human(pre, leg, fores, mouths, scale=1.0):
    root = empty(pre.upper())
    hip = empty(pre + "_hip", root, (0, 0, 330 * PX))
    legB = empty(pre + "_legB", hip, (-0.06, 0.03, 0))
    legF = empty(pre + "_legF", hip, (0.06, -0.03, 0))
    sprite(leg, legB, 0, pre + "_leg_b")
    sprite(leg, legF, 0, pre + "_leg_f")
    torso = empty(pre + "_torso_j", hip)
    sprite(pre + "_torso", torso, 0)
    shB = empty(pre + "_shB", torso, (-90 * PX, 0.03, 245 * PX))
    shF = empty(pre + "_shF", torso, (90 * PX, -0.03, 245 * PX))
    neck = empty(pre + "_neck", torso, (0, -0.01, 290 * PX))
    P = {}
    foreF = {}
    for side, sh in (("B", shB), ("F", shF)):
        sprite(pre + "_upper", sh, 0, pre + "_upper_" + side)
        el = empty(pre + "_el" + side, sh, (0, 0, -100 * PX))
        if side == "F":
            foreF = {n: sprite(n, el, -0.002 - 0.0005 * i, pre + "_" + n + "_F") for i, n in enumerate(fores)}
        else:
            sprite(fores[0], el, -0.002, pre + "_fore_B")
        P["sh" + side], P["el" + side] = sh, el
    head = empty(pre + "_head_j", neck)
    sprite(pre + "_head", head, 0)
    face = {}
    for grp, names, d in (("eyes", ["open", "blink", "wide", "half", "front"], -0.004),
                          ("brows", ["neutral", "up", "angry", "sad"], -0.006),
                          ("mouth", mouths, -0.005)):
        face[grp] = {n: sprite("%s_%s_%s" % ("off" if (grp == "mouth" and pre == "off") else "sam", grp, n), head, d, "%s_%s_%s" % (pre, grp, n)) for n in names}
    sh = quad(pre + "_shadow", 0.8, 0.35, img_mat(os.path.join(PARTS, "shadow.png")))
    sh.parent = root
    sh.rotation_euler = (math.radians(-90), 0, 0)
    sh.location = (0.02, 0, 0.004)
    root.scale = (scale, scale, scale)
    P.update(root=root, hip=hip, torso=torso, neck=neck, head=head, legB=legB, legF=legF, face=face, foreF=foreF, scale=scale)
    return P

def build_bot():
    root = empty("BOT")
    body = empty("bot_body_j", root)
    sprite("bot_body", body, 0)
    shB = empty("bot_shB", body, (-118 * PX, 0.03, 330 * PX))
    shF = empty("bot_shF", body, (118 * PX, -0.03, 330 * PX))
    sprite("bot_arm", shB, 0, "bot_arm_B")
    sprite("bot_arm", shF, 0, "bot_arm_F")
    neck = empty("bot_neck", body, (0, -0.01, 372 * PX))
    head = empty("bot_head_j", neck)
    sprite("bot_head", head, 0)
    ant = empty("bot_ant", head, (0, 0.004, 328 * PX))
    sprite("bot_antenna", ant, 0)
    face = {}
    for grp, names, d in (("eyes", ["open", "blink", "happy", "flat", "side", "think", "wink"], -0.004), ("mouth", ["line", "small", "open", "smirk", "wave"], -0.006)):
        face[grp] = {n: sprite("bot_%s_%s" % (grp, n), head, d) for n in names}
    sh = quad("bot_shadow", 0.75, 0.32, img_mat(os.path.join(PARTS, "shadow.png")))
    sh.parent = root
    sh.rotation_euler = (math.radians(-90), 0, 0)
    sh.location = (0, 0, 0.004)
    return dict(root=root, body=body, shB=shB, shF=shF, neck=neck, head=head, ant=ant, face=face)

SAM = build_human("sam", "sam_leg_sock", ["sam_fore"], ["smile", "flat", "frown", "small", "open", "wide", "o"])
OFF = build_human("off", "off_leg", ["off_fore", "off_fore_glove"], ["flat", "small", "open", "smirk"], 1.22)
BOT = build_bot()
GLOVE = empty("glove_e", OFF["elF"], (0, -0.02, -0.17))
GLOVE.rotation_euler = (0, math.radians(180), 0)
sprite("glove_big", GLOVE, 0, "glove_big")
SHOES = empty("shoes_e", SAM["elF"], (0, -0.012, -0.19))
sprite("shoes", SHOES, 0, "shoes")
# ---------------------------------------------------------------- camera
camd = bpy.data.cameras.new("cam")
camd.sensor_fit = "VERTICAL"
camd.sensor_height = 36
camd.dof.use_dof = True
cam = link(bpy.data.objects.new("cam", camd))
scene.camera = cam

# ---------------------------------------------------------------- animation helpers
def T(f):
    return (f - 1) / FPS

def ease(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)

def back(x, s=1.6):
    x = max(0.0, min(1.0, x))
    x -= 1
    return x * x * ((s + 1) * x + s) + 1

def track(keys, t, blend=0.22, fn=None):
    """keys: list of (time, value-dict). returns blended dict with overshoot"""
    fn = fn or back
    prev = keys[0][1]
    cur = keys[0][1]
    t0 = keys[0][0]
    for tk, v in keys:
        if t >= tk:
            prev, cur, t0 = cur, v, tk
    k = fn((t - t0) / blend)
    return {n: prev.get(n, 0) + (cur.get(n, 0) - prev.get(n, 0)) * k for n in cur}

def step(keys, t):
    v = keys[0][1]
    for tk, val in keys:
        if t >= tk:
            v = val
    return v

def lerp_path(keys, t, fn=ease):
    """keys: (t, value) piecewise eased"""
    if t <= keys[0][0]:
        return keys[0][1]
    for (a, va), (b, vb) in zip(keys, keys[1:]):
        if a <= t <= b:
            k = fn((t - a) / (b - a)) if b > a else 1
            if isinstance(va, tuple):
                return tuple(x + (y - x) * k for x, y in zip(va, vb))
            return va + (vb - va) * k
    return keys[-1][1]

def amp(who, f):
    a = TL["amp"][who]
    return a[f - 1] if 0 < f <= len(a) else 0.0

L = TL["lines"]

def rot(obj, deg):
    obj.rotation_euler = (0, -math.radians(deg), 0)
# ---------------------------------------------------------------- airport data
SP = {
    "idle":     dict(lean=0, head=0, sF=8, eF=14, sB=-8, eB=12),
    "shoes":    dict(lean=0, head=0, sF=22, eF=80, sB=-8, eB=12),
    "tiptoe":   dict(lean=4, head=4, sF=48, eF=25, sB=-48, eB=-25),
    "freeze":   dict(lean=-6, head=-6, sF=60, eF=30, sB=-60, eB=-30),
    "hands_up": dict(lean=-2, head=-4, sF=98, eF=72, sB=-98, eB=-72),
}
OPZ = {
    "block": dict(lean=4, head=6, sF=86, eF=-2, sB=-8, eB=12),
    "idle":  dict(lean=0, head=0, sF=10, eF=14, sB=-10, eB=12),
    "glove": dict(lean=2, head=4, sF=66, eF=96, sB=12, eB=20),
    "snap":  dict(lean=0, head=-2, sF=71, eF=99, sB=12, eB=20),
}
BP = {
    "idle": dict(lean=0, head=0, aF=10, aB=-10),
    "proud": dict(lean=-6, head=-6, aF=-22, aB=22),
    "wave": dict(lean=0, head=4, aF=150, aB=-10),
}
SAM_POSE = [(0, SP["shoes"]), (8.0, SP["tiptoe"]), (9.6, SP["freeze"]), (10.05, SP["hands_up"])]
OFF_POSE = [(0, OPZ["block"]), (2.6, OPZ["idle"]), (12.0, OPZ["glove"]), (12.9, OPZ["snap"]), (13.4, OPZ["glove"])]
BOT_POSE = [(0, BP["idle"]), (5.6, BP["proud"]), (7.0, BP["idle"])]
SAM_MOOD = [(0, ("open", "neutral", "flat")), (5.6, ("wide", "up", "o")), (6.6, ("open", "neutral", "smile")), (8.0, ("half", "neutral", "flat")),
            (9.6, ("wide", "up", "o")), (10.05, ("wide", "sad", "frown")), (12.6, ("front", "up", "wide"))]
OFF_MOOD = [(0, ("half", "angry", "flat")), (2.4, ("open", "neutral", "flat")), (5.6, ("open", "up", "flat")), (6.2, ("open", "neutral", "smirk")),
            (8.0, ("open", "neutral", "flat")), (9.6, ("wide", "up", "flat")), (10.6, ("half", "angry", "flat")), (12.0, ("half", "up", "smirk"))]
BOT_MOOD = [(0, ("open", "line")), (1.3, ("side", "line")), (2.6, ("open", "small")), (5.6, ("happy", "smirk")), (8.0, ("happy", "line")), (12.0, ("happy", "smirk"))]
BOT_PATH = [(0, (0.0, 1.5)), (0.3, (0.0, 1.5)), (1.3, (0.0, 0.85)), (4.5, (0.0, 0.85)), (6.3, (0.0, -0.10)), (7.6, (-1.9, -0.10)),
            (16.6, (-1.9, -0.10))]
SAM_PATH = [(0, (-0.6, 2.6)), (6.9, (-0.6, 2.6)), (7.9, (0.0, 1.25)), (8.3, (0.0, 1.25)), (9.6, (0.0, 0.31)), (16.6, (0.0, 0.31))]
OFF_XY = (1.05, -0.05)
LAMP = [(0, "off"), (5.55, "green"), (6.6, "off"), (9.6, "red")]
BLINK_S = [3.0, 11.2]
BLINK_B = [2.3, 7.0, 14.6]
BLINK_O = [3.4, 10.8, 15.2]
SHOTS = [(0.0, "wide"), (4.0, "front"), (8.0, "front"), (12.0, "med")]
STEP_B = [0.6, 1.1] + [round(4.6 + 0.42 * i, 2) for i in range(6)]

def path_xy(P, t):
    return lerp_path(P, t, lambda x: x)

def speed(P, t):
    a, b = path_xy(P, t - 0.04), path_xy(P, t + 0.04)
    return math.hypot(b[0] - a[0], b[1] - a[1]) / 0.08

def shot_cam(kind, t, ts):
    k = t - ts
    if kind == "wide":
        return (0.55, -4.7 + 0.15 * k, 1.55), (0.55, 0.9, 1.52), 34
    if kind == "front":
        p = 0.12 * max(0.0, t - 10.0)
        return (0.55, -4.3 + p, 1.65), (0.55, 0.5, 1.65), 36
    if kind == "med":
        return (0.60, -3.9 + 0.04 * k, 1.45), (0.60, 0.2, 1.48), 30
    raise ValueError(kind)

def look(cam_loc, target):
    dx, dy, dz = (target[i] - cam_loc[i] for i in range(3))
    yaw = math.atan2(-dx, dy)
    pitch = math.atan2(dz, math.hypot(dx, dy))
    return (math.radians(90) + pitch, 0, yaw)

HIDE = (0.0001, 0.0001, 0.0001)
vis_keys = {}
def show(group, name, f):
    for n, o in group.items():
        vis_keys.setdefault(o, []).append((f, n == name))

def human(H, f, t, poses, mood, blinks, who, xy, mirror=False, shiver=0.0, legsw=0.0, extra_head=0.0):
    p = track(poses, t, 0.18)
    breath = math.sin(t * 2.2) * 1.5
    talk = amp(who, f)
    sc = H["scale"]
    H["root"].location = (xy[0], xy[1], 0.0)
    H["root"].scale = (-sc if mirror else sc, sc, sc)
    H["root"].keyframe_insert("location", frame=f); H["root"].keyframe_insert("scale", frame=f)
    bob = abs(math.sin(legsw)) * 0.012 if legsw else 0.0
    H["hip"].location = (0, 0, 330 * PX + 0.004 * math.sin(t * 2.2) + bob)
    H["hip"].keyframe_insert("location", frame=f)
    rot(H["torso"], p["lean"] + breath * 0.4)
    nod = talk * 10 * math.sin(t * 9)
    rot(H["head"], p["head"] + nod + breath * 0.5 + shiver * 0.4 + extra_head)
    sw = 22 * math.sin(legsw) if legsw else 0.0
    rot(H["shF"], p["sF"] + shiver - sw * 0.4); rot(H["elF"], p["eF"])
    rot(H["shB"], p["sB"] - shiver + sw * 0.4); rot(H["elB"], p["eB"])
    rot(H["legF"], sw); rot(H["legB"], -sw)
    for o in (H["torso"], H["head"], H["shF"], H["elF"], H["shB"], H["elB"], H["legF"], H["legB"]):
        o.keyframe_insert("rotation_euler", frame=f)
    eyes, brows, rest = step(mood, t)
    if any(b <= t < b + 0.13 for b in blinks):
        eyes = "blink"
    if talk > 0.02:
        mouths = H["face"]["mouth"]
        mouth = "small" if talk < 0.08 else "open"
        if mouth not in mouths: mouth = "open"
    else:
        mouth = rest
    show(H["face"]["eyes"], eyes, f)
    show(H["face"]["brows"], brows, f)
    show(H["face"]["mouth"], mouth, f)

scene.view_layers[0].update()
bot_ant = 0.0
bot_ant_v = 0.0
prev_bx = None
sam_ph = 0.0
bot_ph = 0.0
for f in range(1, NF + 1):
    t = T(f)
    # ---- Sam
    sxy = path_xy(SAM_PATH, t)
    v = speed(SAM_PATH, t)
    sam_ph += v / FPS * (14 if t < 8 else 9)
    shiver = 5 * math.sin(t * 32) if t >= 12.6 else (4 * math.sin(t * 30) if 10.3 <= t < 12.0 else 0.0)
    human(SAM, f, t, SAM_POSE, SAM_MOOD, BLINK_S, "sam", sxy, shiver=shiver, legsw=(sam_ph if t < 8.0 else sam_ph * 0.0 + 0.45 * math.sin(sam_ph)) if v > 0.05 else 0.0)
    SHOES.scale = (1, 1, 1) if t < 8.0 else HIDE
    SHOES.keyframe_insert("scale", frame=f)
    # ---- Officer (mirrored: faces the arch)
    nodh = 10 * math.sin((t - 6.0) / 0.8 * 2 * math.pi) if 6.0 <= t < 6.8 else (-12 * ease((t - 10.6) / 1.0) if 10.6 <= t < 12.0 else 0.0)
    human(OFF, f, t, OFF_POSE, OFF_MOOD, BLINK_O, "off", OFF_XY, mirror=True, extra_head=nodh)
    show(OFF["foreF"], "off_fore_glove" if t >= 12.6 else "off_fore", f)
    gs = 0.0001 if t < 12.6 else (1.0 + (0.25 * math.sin(min(1.0, (t - 12.95) / 0.5) * math.pi) if t >= 12.95 else 0.0))
    GLOVE.scale = (gs, gs, gs)
    GLOVE.keyframe_insert("scale", frame=f)
    # ---- Bot
    bxy = path_xy(BOT_PATH, t)
    bv = speed(BOT_PATH, t) if abs(t - 12.0) > 0.06 else 0.0
    bot_ph += bv / FPS * 16
    bp = track(BOT_POSE, t, 0.2)
    talk_b = amp("bot", f)
    walkbob = abs(math.sin(bot_ph)) * 0.03 if bv > 0.05 else 0.0
    BOT["root"].location = (bxy[0], bxy[1], 0.05 + 0.012 * math.sin(t * 2.6) + walkbob)
    BOT["root"].keyframe_insert("location", frame=f)
    rot(BOT["body"], bp["lean"] + (4 * math.sin(bot_ph) if bv > 0.05 else 0))
    rot(BOT["head"], bp["head"] + talk_b * 8 * math.sin(t * 8))
    wave = 25 * math.sin(t * 9) if t >= 12.4 else 0.0
    aw = 15 * math.sin(bot_ph) if bv > 0.05 else 0.0
    rot(BOT["shF"], bp["aF"] + wave + aw)
    rot(BOT["shB"], bp["aB"] - aw)
    vel = 0 if prev_bx is None or abs(bxy[0] - prev_bx) > 0.3 else (bxy[0] - prev_bx) * FPS
    prev_bx = bxy[0]
    force = -vel * 9 - bot_ant * 60 - bot_ant_v * 6
    if abs(t - 5.6) < 1 / FPS:
        bot_ant_v += 40
    bot_ant_v += force / FPS
    bot_ant += bot_ant_v / FPS
    rot(BOT["ant"], max(-35, min(35, bot_ant + talk_b * 6 * math.sin(t * 14))))
    for o in (BOT["body"], BOT["head"], BOT["shF"], BOT["shB"], BOT["ant"]):
        o.keyframe_insert("rotation_euler", frame=f)
    beyes, brest = step(BOT_MOOD, t)
    if any(b <= t < b + 0.12 for b in BLINK_B):
        beyes = "blink"
    bm = ("small" if talk_b < 0.1 else "open") if talk_b > 0.02 else brest
    show(BOT["face"]["eyes"], beyes, f)
    show(BOT["face"]["mouth"], bm, f)
    # ---- arch lamp (red flashes for 1.6 s, then stays on)
    st_l = step(LAMP, t)
    if st_l == "red" and t < 11.2 and int((t - 9.6) / 0.2) % 2 == 1:
        st_l = "off"
    show(LAMPS, st_l, f)
    for n, o in STRIPS.items():
        vis_keys.setdefault(o, []).append((f, n.replace("_r", "") == st_l))
    for n, l in GLOW.items():
        l.energy = 60 if st_l == n else 0
        l.keyframe_insert("energy", frame=f)
    # ---- camera
    si = max(i for i, (ts, _) in enumerate(SHOTS) if t >= ts)
    ts, kind = SHOTS[si]
    loc, tgt, lens = shot_cam(kind, t, ts)
    cam.location = loc
    cam.rotation_euler = look(loc, tgt)
    camd.lens = lens
    camd.dof.aperture_fstop = 5.6
    camd.dof.focus_distance = math.dist(loc, (tgt[0], 0.3, tgt[2]))
    cam.keyframe_insert("location", frame=f)
    cam.keyframe_insert("rotation_euler", frame=f)
    camd.keyframe_insert("lens", frame=f)
    camd.dof.keyframe_insert("focus_distance", frame=f)
    if f % 100 == 0:
        print("BBB baked frame", f, "/", NF)

for o, seq in vis_keys.items():
    last = None
    for f, vis in seq:
        if vis != last:
            o.hide_render = not vis
            o.hide_viewport = not vis
            o.keyframe_insert("hide_render", frame=f)
            o.keyframe_insert("hide_viewport", frame=f)
            last = vis

# ---------------------------------------------------------------- render settings
scene.render.engine = "CYCLES"
scene.cycles.samples = SAMPLES
scene.cycles.use_adaptive_sampling = True
scene.cycles.use_denoising = True
scene.cycles.max_bounces = 4
scene.cycles.diffuse_bounces = 2
scene.cycles.glossy_bounces = 2
scene.cycles.transparent_max_bounces = 32
scene.render.use_persistent_data = True
scene.view_settings.view_transform = "Standard"
scene.view_settings.look = "None"

def use_gpu():
    if CPU_ONLY:
        return "CPU"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        for kind in ("OPTIX", "CUDA", "HIP", "ONEAPI", "METAL"):
            try:
                prefs.compute_device_type = kind
            except Exception:
                continue
            prefs.get_devices()
            gpus = [d for d in prefs.devices if d.type == kind]
            if gpus:
                for d in prefs.devices:
                    d.use = d.type == kind
                scene.cycles.device = "GPU"
                try:
                    scene.cycles.denoiser = "OPTIX" if kind == "OPTIX" else "OPENIMAGEDENOISE"
                except Exception:
                    pass
                return kind + ": " + ", ".join(d.name for d in gpus)
    except Exception as e:
        print("GPU setup failed:", e)
    return "CPU"

print("BBB render device ->", use_gpu())

# ---------------------------------------------------------------- edit scene: 3D shot + captions + sound
edit.render.resolution_x, edit.render.resolution_y = 1080, 1920
edit.render.resolution_percentage = PCT
edit.render.fps = FPS
edit.frame_start, edit.frame_end = START, END
edit.view_settings.view_transform = "Standard"
se = edit.sequence_editor_create()
strips = se.strips if hasattr(se, "strips") else se.sequences
sc = strips.new_scene("shot", scene, 1, 1)
sc.frame_final_duration = NF
CAPDIR = os.path.join(HERE, "caps")
NOOV = os.environ.get("BBB_NOOV", "") == "1" or GREY
for c in ([] if NOOV else CAPS):
    f0 = int(round(c["start"] * FPS)) + 1
    f1 = max(f0 + 1, int(round(c["end"] * FPS)) + 1)
    im = strips.new_image("cap", os.path.join(CAPDIR, c["file"]), 3, f0)
    im.frame_final_duration = f1 - f0
    im.blend_type = "ALPHA_OVER"
    if c["first"]:
        try:
            tr = im.transform
            tr.origin = (0.5, 0.71)
            for df, s in ((0, 0.78), (2, 1.08), (4, 1.0)):
                tr.scale_x = tr.scale_y = s
                tr.keyframe_insert("scale_x", frame=f0 + df)
                tr.keyframe_insert("scale_y", frame=f0 + df)
        except Exception as e:
            print("caption pop skipped:", e)
OVS = json.load(open(os.path.join(HERE, "overlays.json")))
for c in ([] if NOOV else OVS):
    f0 = int(round(c["start"] * FPS)) + 1
    f1 = max(f0 + 1, int(round(c["end"] * FPS)) + 1)
    im = strips.new_image("ov", os.path.join(CAPDIR, c["file"]), c.get("ch", 4), f0)
    im.frame_final_duration = f1 - f0
    im.blend_type = "ALPHA_OVER"
    if c["file"].startswith("ov_photo"):   # slow push-in on the grandma photo
        try:
            tr = im.transform
            tr.origin = (0.5, 0.5)
            s0 = 1.0 + 0.05 * (c["start"] - 13.0) / 3.0
            s1 = 1.0 + 0.05 * (c["end"] - 13.0) / 3.0
            for fr, s in ((f0, s0), (f1 - 1, s1)):
                tr.scale_x = tr.scale_y = s
                tr.keyframe_insert("scale_x", frame=fr)
                tr.keyframe_insert("scale_y", frame=fr)
        except Exception as e:
            print("photo push-in skipped:", e)
snd = strips.new_sound("audio", os.path.join(HERE, "skit_audio.wav"), 5, 1)

def render_stills(frames):
    edit.render.image_settings.file_format = "PNG"
    for fr in frames:
        edit.frame_set(fr)
        edit.render.filepath = os.path.join(HERE, "still_%04d.png" % fr)
        bpy.ops.render.render(write_still=True, scene=edit.name)

if STILLS:
    render_stills([int(x) for x in STILLS.split(",")])
else:
    im = edit.render.image_settings
    try:
        im.media_type = "VIDEO"
    except Exception:
        pass
    im.file_format = "FFMPEG"
    ff = edit.render.ffmpeg
    ff.format = "MPEG4"
    ff.codec = "H264"
    ff.constant_rate_factor = "PERC_LOSSLESS"
    ff.audio_codec = "AAC"
    ff.audio_bitrate = 192
    ff.audio_channels = "STEREO"
    edit.render.filepath = os.path.join(HERE, OUTNAME)
    print("BBB rendering", END, "frames ->", edit.render.filepath)
    bpy.ops.render.render(animation=True, scene=edit.name)
    print("BBB DONE ->", edit.render.filepath)
